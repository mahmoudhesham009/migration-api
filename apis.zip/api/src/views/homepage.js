// import makeData from 'data/makeData.dataTable'
import React, { useState, useRef, useMemo, useCallback } from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { IconButton, Tooltip } from '@mui/material'
import moment from 'moment';
import HtmlReactParser from 'html-react-parser';
//*** shared ***
import ReactCardDatatable from 'shared/views/ReactCardDatatable';
//*** components ***/
import DateColumnFilter from 'components/DataTable/utils/DateColumnFilter';
// import Datepicker from 'components/FormFields/Datepicker'
// *** hooks ***
import { DT_FILTER_LBL_NUMBER_OF_RECORDS } from 'hooks/useFilterText'
// *** Icons ***
import DynamicFormIcon from '@mui/icons-material/DynamicForm';
// import EditIcon from '@mui/icons-material/Edit';
// import DeleteIcon from '@mui/icons-material/Delete';
// *** styles ***
import { createUseStyles } from 'react-jss'
import { DataTableActionStyles } from 'assets/styles/components/datatable.styles'
import styles from 'assets/styles/views/homepage';
const useDtStyles = createUseStyles(DataTableActionStyles)
const useStyles = createUseStyles(styles)




// const serverData = makeData(50)
function Homepage() {
  let navigate = useNavigate();
  // const fetchIdRef = useRef(0)
  const dtClasses = useDtStyles()
  const classes = useStyles()

  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [pageCount, setPageCount] = useState(0)

  // const handleRowMetaChange = useCallback((data, action) => {
  //   console.log("data: ", data);
  //   console.log("action: ", action);
  // })

  const columns = useMemo(() => {
    return (
      [
        {
          Header: 'Process Name',
          id: "processName",
          sortable: true,
          accessor: 'processName',
          filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
          filter: 'fuzzyText',
        },
        {
          Header: 'From Date',
          id: 'fromDate',
          sortable: true,
          accessor: ({ fromDate }) => moment(fromDate).format("YYYY/MM/DD"),
          Filter: DateColumnFilter,
        },
        {
          Header: 'To Date',
          id: 'toDate',
          sortable: true,
          accessor: ({ toDate }) => moment(toDate).format("YYYY/MM/DD"),
          Filter: DateColumnFilter,
        },
        {
          Header: 'Created Date',
          id: 'createdDate',
          sortable: true,
          accessor: ({ createdDate }) => moment(createdDate).format("YYYY/MM/DD"),
          Filter: DateColumnFilter,
        },
        {
          Header: 'Modify Date',
          id: 'modifyDate',
          sortable: true,
          accessor: ({ modifyDate }) => moment(modifyDate).format("YYYY/MM/DD"),
          Filter: DateColumnFilter,
        },
        {
          Header: 'Status',
          id: "status",
          sortable: true,
          accessor: 'status',
          filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
          filter: 'fuzzyText',
        },
        {
          Header: '',
          id: 'dynamicFormList',
          sortable: false,
          isRowActions: true,
          extraStyles: { pointerEvents: "none" },
          extraHeaderStyles: { width: "100%", textAlign: "center" },
          Filter: () => <div className={dtClasses.hiddenFilter}></div>,
          accessor: ({ processName, id }) => {
            return (
              <Tooltip
                title={HtmlReactParser(`
                    <div style="text-align: center; padding: 10px 5px">
                      <span style="margin-bottom: 10px; display: inline-block">
                        Show <span style="background: #9c27b0; padding: 2px 5px; border-radius: 50px">${processName}</span> List
                      </span>
                      <br /> 
                      <span>
                        JobID: <span style="background: #d81b60; padding: 2px 5px; border-radius: 50px">${id}</span>
                      </span>
                    </div>
                `)}
                placement="left"
              >
                <IconButton
                  className={classes.viewFormListButton}
                  onClick={() => navigate(`/dynamic-form-list?jobID=${id}`)}
                >
                  <DynamicFormIcon />
                </IconButton>
              </Tooltip>
            )
          }
        },
        // {
        //   Header: "Actions",
        //   id: 'Actions',
        //   sortable: false,
        //   isRowActions: true,
        //   extraStyles: { pointerEvents: "none" },
        //   extraHeaderStyles: { width: "100%", textAlign: "center" },
        //   Filter: () => <div className={dtClasses.hiddenFilter}></div>,
        //   accessor: d => (
        //     <div className={dtClasses.actionButtonsContainer}>
        //       <Tooltip title="Edit">
        //         <IconButton
        //           className={`${dtClasses.actionButton} ${dtClasses.editActionBtn}`}
        //           tabIndex={-1}
        //           onClick={() => handleRowMetaChange(d, "Edit")}
        //         >
        //           <EditIcon />
        //         </IconButton>
        //       </Tooltip>

        //       <Tooltip title="Delete">
        //         <IconButton
        //           className={`${dtClasses.actionButton} ${dtClasses.deleteActionBtn}`}
        //           tabIndex={-1}
        //           onClick={() => handleRowMetaChange(d, "Delete")}
        //         >
        //           <DeleteIcon />
        //         </IconButton>
        //       </Tooltip>
        //     </div >
        //   ),
        // },
      ]
    )
  }, [])

  const fetchData = useCallback(({ pageSize, pageIndex, filters }) => {

    // console.log("filters: ", filters);

    setLoading(true)
    // ##################################################################

    // const fetchId = ++fetchIdRef.current
    // setTimeout(() => {
    //   if (fetchId === fetchIdRef.current) {
    //     const startRow = pageSize * pageIndex
    //     const endRow = startRow + pageSize
    //     setData(serverData.slice(startRow, endRow))
    //     setPageCount(Math.ceil(serverData.length / pageSize))
    //     setLoading(false)
    //   }
    // }, 3000)

    // ##################################################################

    // const body = {
    //     pageIndex: pageIndex,
    //     pageSize: pageSize,
    //     sortBy: [],
    //     filters: filters,
    //     columnOrder: [],
    //     hiddenColumns: []
    // }

    const headers = {
      "Content-type": "application/json"
    }

    axios
        .get("/api/getAllJobs", { headers })
        .then(response => {
            setLoading(false)
            setData(response.data)
            // setPageCount(response.data.pagination.pageCount)
        })
        .catch(error => {
            console.log(error)
            setLoading(false)
        })

  }, [])





  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh" }}>
      <ReactCardDatatable
        columns={columns}
        data={data}
        fetchData={fetchData}
        loading={loading}
        pageCount={pageCount}
        PageSizeList={[10, 20, 25, 50, 75, 100]}
      />
    </div>
  )
}

export default Homepage