import { memo } from 'react'
import PropTypes from 'prop-types';
import HtmlParser from 'html-react-parser';
// *** styles ***
import styles from 'assets/styles/views/errorPage.styles';
import { createUseStyles } from 'react-jss';
const useStyles = createUseStyles(styles)


function ErrorPage({ errorNumber, errorMessage, extraJSX }) {
    const classes = useStyles();
    return (
        <div className={classes.root}>
            <div>
                {errorNumber && <h1>{errorNumber}</h1>}
                <div>
                    <h2>{HtmlParser(errorMessage)}</h2>                    
                </div>
            </div>
            {extraJSX && extraJSX}
        </div>
    )
}


ErrorPage.propTypes = {
    errorNumber: PropTypes.number, 
    errorMessage: PropTypes.string.isRequired, 
    extraJSX: PropTypes.node
}

export default memo(ErrorPage)