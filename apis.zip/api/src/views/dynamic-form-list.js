import React, { useState, useRef, useEffect, useCallback } from 'react'
import { Link } from 'react-router-dom';
import queryString from 'query-string';
import axios from 'axios';
import _ from 'lodash';
import { Accordion, AccordionDetails, AccordionSummary, Container, Typography, IconButton } from '@mui/material'
// *** views ***
import ErrorPage from 'views/errorPage';
// *** components ***
import DynamicForm from 'components/DynamicForm'
import LoadingProgress from 'components/loading';
//*** modals ***
import SaveModal from 'modals/dynamic-form-list.modal';
// *** config ***
// import PtoResponse from 'config/new-pto-Json.json';
import ProcessApi from 'config/process-api'
//*** Icons ***
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import TagIcon from '@mui/icons-material/Tag';
//*** styles ***/
import styles from 'assets/styles/views/dynamic-form-list.styles';
import { createUseStyles } from 'react-jss';
const useStyles = createUseStyles(styles)


const saveModalInitialState = {
  formId: null,
  open: false,
  status: undefined,
  title: "",
  description: ""
}

function DeploymentForm({ formData, deploymentId, jobID }) {
  const formikRef = useRef(null)
  const [expanded, setExpanded] = useState(formData[0]?.formKey);
  const [saveModal, setSaveModal] = useState(saveModalInitialState)

  const handleAccordionChange = (panel) => (event, isExpanded) => setExpanded(isExpanded ? panel : false);
  const handleCloseModal = () => setSaveModal(saveModalInitialState)

  const onSubmit = useCallback((values, { formId }) => {

    const data = {
      "taskDef": formId,
      "deploymentID": deploymentId,
      "jobID": jobID,
      "formValues": _.map(values, (value, id) => { return { id, value } })
    }

    const headers = {
      'Content-Type': 'application/json'
    }

    axios.patch(`/api/update/${jobID}`, data, { headers })
      .then(response => {
        formikRef.current.setSubmitting(false)
        setSaveModal({
          formId: formId,
          open: true,
          status: "success",
          title: "Success",
          description: "Data was saved successfully."
        })
      })
      .catch(error => {
        formikRef.current.setSubmitting(false)
        setSaveModal({
          formId: formId,
          open: true,
          status: "failure",
          title: "Failure",
          description: "Something went wrong while saving data."
        })
      })

  }, [])


  return formData.map(({ deltaType, formFields, formKey, initialValues, taskDef, taskName, validationSchema }) => (
    <div key={`dynamic-form-${formKey}`}>
      <SaveModal
        {...saveModal}
        open={saveModal.open && saveModal.formId === formKey}
        onCloseModal={handleCloseModal}
      />
      <Accordion
        expanded={expanded === formKey}
        onChange={handleAccordionChange(formKey)}
        TransitionProps={{ unmountOnExit: true }}
      >
        <AccordionSummary id={`${formKey}-panel-header`} expandIcon={<ExpandMoreIcon />}>
          <Typography sx={{ width: '33%', flexShrink: 0 }}>
            <strong>{taskDef}</strong>
          </Typography>

          <Typography sx={{ color: 'text.secondary' }}>
            {taskName}
          </Typography>

        </AccordionSummary>
        <AccordionDetails>

          <DynamicForm
            ref={formikRef}
            formId={formKey}
            initialValues={initialValues}
            validationSchema={validationSchema}
            formFields={formFields}
            onSubmit={onSubmit}
          />

        </AccordionDetails>
      </Accordion>
    </div>
  ))
}

function DynamicFormList() {
  const classes = useStyles();

  const parsed = queryString.parse(window.location.search);
  const [loading, setLoading] = useState(true)
  const [deployments, setDeployments] = useState([])
  const [expanded, setExpanded] = useState(null);

  const handleAccordionChange = (panel) => (event, isExpanded) => setExpanded(isExpanded ? panel : false);

  useEffect(() => {

    // setTimeout(() => {
    //   setDeployments(ProcessApi(PtoResponse))
    //   setLoading(false)
    //   setExpanded(PtoResponse[0].DeploymentId)
    // }, 3000)

    const headers = {
      'Content-Type': 'application/json'
    }

    axios
      .get(`/api/getJobsById/${parsed?.jobID}`, { headers })
      .then(response => {
        setLoading(false)
        setDeployments(ProcessApi(response.data))
        setExpanded(Array.isArray(response.data) && response.data.length > 0 ? response.data[0].DeploymentId : null)
      })
      .catch(error => {
        setLoading(false)
        console.log("error: ", error);
        throw new Error("Something went wrong while fetching data!")
      })
  }, [])



  if (!Boolean(parsed?.jobID)) return (
    <ErrorPage
      errorMessage="Oops!&nbsp;&nbsp;<strong>[ Job ID ]</strong>&nbsp;&nbsp;is not present to complete this action."
      extraJSX={
        <Link to="/">
          Back to Homepage
        </Link>
      }
    />
  )
  else return (
    <>
      {loading ?
        <LoadingProgress /> :
        <Container sx={{ my: 8 }}>
          {deployments.map(({ DeploymentId, formData }) => (
            <Accordion
              key={`deployment--${DeploymentId}`}
              expanded={expanded === DeploymentId}
              TransitionProps={{ unmountOnExit: true }}
              onChange={handleAccordionChange(DeploymentId)}
            >

              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                className={classes.accordionSummaryRoot}
              >
                <Typography>
                  <IconButton>
                    <TagIcon />
                  </IconButton>
                  <strong>Deployment ID: {DeploymentId}</strong>
                </Typography>
              </AccordionSummary>
              <AccordionDetails>

                <DeploymentForm
                  key={`deployment-${DeploymentId}`}
                  jobID={parsed.jobID}
                  deploymentId={DeploymentId}
                  formData={formData}
                />

              </AccordionDetails>
            </Accordion>
          ))}
        </Container>}
    </>
  )
}

export default React.memo(DynamicFormList)