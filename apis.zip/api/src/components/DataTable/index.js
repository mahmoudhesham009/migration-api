import React, { useState, useEffect, useMemo } from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames'
import { useTable, useSortBy, useFilters, usePagination, useAsyncDebounce } from 'react-table'
import {
    TableContainer,
    Table as MuiTable,
    TableBody,
    TableCell,
    TableHead,
    TableRow,
    Tooltip,
    CircularProgress,
    Grid,
    Typography,
    Button
} from '@mui/material'
//*** Components ***
import CustomInput from 'components/FormFields/CustomInput';
import CustomDropdown from 'components/FormFields/CustomDropdown';
import FloatingActionButton from 'components/FormFields/CustomButton/FloatingActionButton';
//*** Hooks ***
import useDropdownGenerator from 'hooks/useDropdownGenerator'
//*** Custom Filters ***
import DefaultColumnFilter from './utils/DefaultColumnFilter'
//*** Icons ***
import RefreshIcon from '@mui/icons-material/Refresh';
import { faSort, faSortDown, faSortUp } from '@fortawesome/fontawesome-free-solid'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import ArchiveIcon from '@mui/icons-material/Archive';
//*** Styles ***
import { DataTableStyles, TableCellStyles, TableRowStyles } from 'assets/styles/components/datatable.styles'
import { createUseStyles } from 'react-jss';
import { withStyles } from '@mui/styles';
const useStyles = createUseStyles(DataTableStyles)

const StyledTableCell = withStyles(TableCellStyles)(TableCell);
const StyledTableRow = withStyles(TableRowStyles)(TableRow);

export const FilterContext = React.createContext()


function ReactDTable({ columns, data, fetchData, loading, pageCount: controlledPageCount, PageSizeList, extraFooterContent, exportDataType, resetExportDataType }) {
    const classes = useStyles()
    const [clearAllFilters, setClearAllFilters] = useState(false)
    // TODO : default column filter for columns. even if you don't pass any custom filter.
    const defaultColumn = useMemo(() => ({ Filter: DefaultColumnFilter }), [])
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        prepareRow,
        page,
        canPreviousPage,
        canNextPage,
        pageOptions,
        pageCount,
        gotoPage,
        nextPage,
        previousPage,
        setPageSize,
        // Get the state from the instance
        state: { pageIndex, pageSize, filters },
        setAllFilters,
        exportData
    } = useTable(
        {
            columns,
            data,
            defaultColumn,
            autoResetPage: false,
            initialState: { pageIndex: 0 }, // Pass our hoisted table state
            manualPagination: true, // Tell the usePagination
            // hook that we'll handle our own data fetching
            // This means we'll also have to provide our own
            // pageCount.
            pageCount: controlledPageCount,
            autoResetFilters: false,
            autoResetSortBy: false,
        },
        useFilters,
        useSortBy,
        usePagination,
        useAsyncDebounce
    )



    // TODO: Debounce our onFetchData call for 100ms
    const onFetchDataDebounced = useAsyncDebounce(fetchData, 100)
    // TODO: Listen for changes in pagination and use the state to fetch new data.
    useEffect(() => {
        onFetchDataDebounced({ pageIndex, pageSize, filters })
    }, [onFetchDataDebounced, pageIndex, pageSize, filters])
    useEffect(() => {
        fetchData({ pageIndex, pageSize, filters })
    }, [fetchData, pageIndex, pageSize, filters])

    const defaultPageSize = useDropdownGenerator(PageSizeList, 'Rows', "end")

    
    return (
        <>
            {/* <button onClick={() => { exportData("csv", false) }}>Export Current View as CSV</button> */}

            <Grid container spacing={5} className={classNames(classes.topContainer)}>
                <Grid item md={3} className={classNames({ [classes.disabledRootNavigationButton]: !canPreviousPage })}>
                    <Button
                        onClick={() => previousPage()}
                        disabled={!canPreviousPage}
                        fullWidth
                        classes={{
                            root: classes.rootNavigationButton
                        }}
                    >
                        Previous
                    </Button>
                </Grid>
                <Grid item md={5} >
                    <Grid container spacing={3}>
                        <Grid item md={6}>
                            <CustomInput
                                fullWidth
                                labelText="Go to page"
                                value={`${pageIndex + 1}`}
                                onChange={e => {
                                    const page = e.target.value ? Number(e.target.value) - 1 : 0
                                    gotoPage(page)
                                }}
                            // style={{ paddingTop: 5 }}                                
                            />
                        </Grid>

                        <Grid item md={6}>
                            <div style={{ marginTop: 12 }}>
                                <CustomDropdown
                                    id="PageSizeDropdown"
                                    value={pageSize}
                                    onChange={e => setPageSize(Number(e.target.value))}
                                    items={defaultPageSize}
                                />
                            </div>
                        </Grid>

                    </Grid>
                </Grid>
                <Grid item md={1} className={classes.resetBtnContainer}>
                    <FloatingActionButton
                        toolTipTitle="Refresh"
                        variant="round"
                        icon={<RefreshIcon />}
                        className={classes.resetDTBtn}
                        onClick={() => {
                            setAllFilters([])
                            setClearAllFilters(true)
                            // toggleFilterState()
                            setTimeout(() => { setClearAllFilters(false) }, 2000);

                        }}
                    />
                </Grid>
                <Grid item md={3} className={classNames({ [classes.disabledRootNavigationButton]: !canNextPage })}>
                    <Button
                        onClick={() => nextPage()}
                        disabled={!canNextPage}
                        fullWidth
                        classes={{
                            root: classes.rootNavigationButton
                        }}
                    >
                        Next
                    </Button>
                </Grid>
            </Grid>

            <TableContainer
                id="table-container"
                className={classes.tableContainer}
            >
                <MuiTable
                    {...getTableProps()}
                    stickyHeader
                    size="small"
                    sx={{ height: page.length === 0 || loading ? "100%" : "auto" }}
                >
                    <TableHead>
                        {headerGroups.map(headerGroup => (
                            <TableRow {...headerGroup.getHeaderGroupProps()}>
                                {
                                    headerGroup.headers.map(column => (
                                        <TableCell
                                            key={column.id}
                                            {...column.getHeaderProps({
                                                style: {
                                                    borderBottom: "none",
                                                    backgroundColor: "#fff",
                                                    ...column.extraStyles
                                                },
                                            })}>

                                            <div {...column.getHeaderProps(column.getSortByToggleProps())}>
                                                <div className={classes.headerTitleWrapper}>

                                                    <div style={{ ...column.extraHeaderStyles }}>{column.render('Header')}</div>

                                                    {
                                                        column.sortable ?
                                                            column.isSorted
                                                                ? column.isSortedDesc
                                                                    ? <FontAwesomeIcon icon={faSortDown} />
                                                                    : <FontAwesomeIcon icon={faSortUp} />
                                                                : <FontAwesomeIcon icon={faSort} style={{ color: "rgba(0,0,0,0.2)" }} />
                                                            : <React.Fragment />
                                                    }

                                                </div>
                                            </div>

                                            {
                                                column.canFilter &&
                                                <div>
                                                    <FilterContext.Provider value={clearAllFilters}>
                                                        {column.render('Filter')}
                                                    </FilterContext.Provider>
                                                </div>
                                            }

                                        </TableCell>
                                    ))
                                }
                            </TableRow>
                        ))}
                    </TableHead>
                    <TableBody {...getTableBodyProps()}>
                        {
                            loading ?
                                <tr>
                                    <td colSpan="10000000000000000" className={classes.circularProgressHolder}>
                                        <CircularProgress size={150} className={classes.circularProgress} />
                                    </td>
                                </tr>
                                :
                                page.length === 0 && !loading ?
                                    <tr>
                                        <td colSpan="10000000000000000" className={classes.noData}>
                                            <ArchiveIcon className={classes.emptyDataIcon} />
                                            <Typography className={classes.emptyDataTypography} variant="h4" component="h4">No Data</Typography>
                                        </td>
                                    </tr>
                                    :
                                    page.map((row, i) => {
                                        prepareRow(row)
                                        return (
                                            <StyledTableRow  {...row.getRowProps()}>
                                                {
                                                    row.cells.map(cell => {
                                                        return (
                                                            <StyledTableCell
                                                                key={cell.id}
                                                                {...cell.getCellProps({ style: { textAlign: cell.column.centerContent && "center", ...cell.column.extraCellWrapperStyles } })}
                                                            >
                                                                {
                                                                    cell.column.isRowActions ?
                                                                        <div style={{ display: "flex", justifyContent: "center" }}>{cell.render('Cell')}</div>
                                                                        :
                                                                        <React.Fragment>
                                                                            <Tooltip
                                                                                title={
                                                                                    cell.column.customToolTip ?
                                                                                        cell.column.toolTipTitle :
                                                                                        cell.render('Cell')
                                                                                }
                                                                                placement="bottom"
                                                                            >
                                                                                <span style={{ ...cell.column.extraCellContentStyles }} >{cell.render('Cell')}</span>
                                                                            </Tooltip>
                                                                        </React.Fragment>
                                                                }
                                                            </StyledTableCell>
                                                        )
                                                    })
                                                }
                                            </StyledTableRow>
                                        )
                                    })
                        }
                    </TableBody>
                </MuiTable>
            </TableContainer>


            {
                !loading && data.length > 0 ?
                    <div className={classes.footerDetails}>
                        <div>
                            Showing
                            {' '}
                            <strong>{page.length}</strong>
                            {' '}
                            of
                            {' '}
                            <strong>{controlledPageCount * pageSize}</strong>
                            {' '}
                            results
                        </div>
                        <div>
                            Page
                            {' '}
                            <strong>{pageIndex + 1}</strong>
                            {' '}
                            of
                            {' '}
                            <strong>{pageOptions.length}</strong>
                        </div>
                    </div>
                    :
                    <div className={classes.footerDetails} style={{ paddingBottom: 25 }}></div>
            }

            {
                !loading && Boolean(extraFooterContent) &&
                <div id="DTExtraFooterDetails" style={{ padding: "0px 16px 0px 16px" }}></div>
            }

        </>
    )
}

export default React.memo(ReactDTable)