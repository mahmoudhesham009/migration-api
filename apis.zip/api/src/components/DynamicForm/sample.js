import React, { useRef } from 'react'
import { Formik, Form, Field, FieldArray } from 'formik';
import * as Yup from 'yup';
// *** components ***
import CustomInput from 'components/FormFields/CustomInput';
import CustomButton from 'components/FormFields/CustomButton'
// import CustomCheckboxList from 'components/FormFields/CustomCheckbox/checkbox-list';
import IOSSwitch from 'components/FormFields/CustomSwitch/IOSSwitch'
import CustomRadioGroup from 'components/FormFields/CustomRadioGroup';

const initialValues = {
  email: "",
  password: "",
  // beverages: []
  toggle: false,
  gender: ""
}

const validationSchema = Yup.object({
  email: Yup.string().email().required("Required Field."),
  password: Yup.string().required("Required Field."),
  // beverages: Yup.array().min(1).required(),
  toggle: Yup.boolean().required("Required Field."),
  gender: Yup.string().required("Required Field.")
})


// const beverageList = [
//   { id: 1, name: "beverages", labelText: "Coffee", value: "coffee" },
//   { id: 2, name: "beverages", labelText: "Tea", value: "tea" },
//   { id: 3, name: "beverages", labelText: "Lemon Lime Juice", value: "lemonLimeJuice" },
//   { id: 4, name: "beverages", labelText: "Cardamom Thandai", value: "cardamomThandai" },
//   { id: 5, name: "beverages", labelText: "Watermelon & Dry Fruit Punch", value: "watermelonDryFruitPunch" },
//   { id: 6, name: "beverages", labelText: "Christmas Gluhwein", value: "christmasGluhwein" },
//   { id: 7, name: "beverages", labelText: "Cucumber, Kale And Spinach Juice", value: "cucumberKaleAndSpinachJuice" },
//   { id: 8, name: "beverages", labelText: "Mango Mastani", value: "mangoMastani" }
// ]


const genderOptions = [
  { id: 1, label: "Male", value: "male" },
  { id: 2, label: "Female", value: "female" },
]

function SampleDynamicForm() {

  const formikRef = useRef(null)

  const onSubmit = values => {


    setTimeout(() => {
      console.log(`%c values: `, "color: #eea134");
      console.log(values);
      formikRef.current.setSubmitting(false)
    }, 3000);


    
  }

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
      innerRef={formikRef}
    >

      {({
        errors,
        values,
        touched,
        isSubmitting,
        handleSubmit
      }) => (
        <Form onSubmit={handleSubmit}>
          <div style={{ margin: 25 }}>


            <Field name="email">
              {({ field: { name, value, onChange, onBlur }, form, meta: { touched, error } }) => (
                <CustomInput
                  name={name}
                  value={value}
                  disabled={isSubmitting}
                  labelText="Email"
                  error={Boolean(touched && error)}
                  helperText={error && touched ? error : ""}
                  fullWidth={true}
                  margin="normal"
                  onChange={onChange}
                  onBlur={onBlur}
                />
              )}
            </Field>


            <Field name="password">
              {({ field: { name, value, onChange, onBlur }, form, meta: { touched, error } }) => (
                <CustomInput
                  name={name}
                  value={value}
                  disabled={isSubmitting}
                  labelText="Password"
                  error={Boolean(touched && error)}
                  helperText={error && touched ? error : ""}
                  fullWidth={true}
                  margin="normal"
                  onChange={onChange}
                  onBlur={onBlur}
                />
              )}
            </Field>


            <Field name="toggle">
              {({ field: { name, value, onChange, onBlur }, form, meta }) => (
                <IOSSwitch
                  key={`form-switch-${name}`}
                  name={name}
                  label={name}
                  checked={Boolean(value)}
                  disabled={isSubmitting}
                  onChange={onChange}
                />
              )}
            </Field>



            <Field name="gender">
              {({ field: { name, value, onChange }, form, meta }) => {
                return (
                  <CustomRadioGroup
                    name={name}
                    formLabel="Gender"
                    direction="row"
                    size="small"
                    labelPlacement='end'
                    margin="normal"
                    fullWidth
                    defaultValue={value}
                    disabled={isSubmitting}
                    onChange={onChange}
                    options={genderOptions.map(({ id, label, value }) => ({ id, label, value }))}
                    error={Boolean(touched.gender && errors.gender)}
                    helperText={Boolean(touched.gender && errors.gender) ? errors.gender : ""}
                  />
                )
              }}
            </Field>



            {/* <FieldArray
              name="beverages"
              render={arrayHelpers => (
                <CustomCheckboxList
                  formLabelText="Select your favorite Beverages"
                  fullWidth
                  margin="normal"
                  direction="column"
                  fieldArrayValues={arrayHelpers.form.values.beverages}
                  error={Boolean(touched.beverages && errors.beverages)}
                  helperText={Boolean(touched.beverages && errors.beverages) ? errors.beverages : ""}
                  checkList={beverageList}
                />
              )}
            /> */}

            <br />
            <br />


            <CustomButton
              type="submit"
              innerContent="Submit"
              variant='contained'
              color="primary"
              disabled={isSubmitting}
            />

            <h2>Values</h2>
            <pre>{JSON.stringify(values, null, 2)}</pre>
          </div>
        </Form>
      )}
    </Formik>
  )
}

export default SampleDynamicForm