import React from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
// *** styles ***
import { createUseStyles } from "react-jss";
import styles from "assets/styles/components/Card/cardIcon.style";
const useStyles = createUseStyles(styles);

function CardIcon({ className, children, color }) {

    const classes = useStyles();
    const cardIconClasses = classNames({
        [classes.cardIcon]: true,
        [classes[color + "CardHeader"]]: color,
        [className]: className !== undefined
    });

    return (
        <div className={cardIconClasses}>
            {children}
        </div>
    );
}

CardIcon.propTypes = {
    className: PropTypes.string,
    color: PropTypes.oneOf([
        "warning",
        "success",
        "danger",
        "info",
        "primary",
        "rose"
    ]),
    children: PropTypes.node
};


export default React.memo(CardIcon)