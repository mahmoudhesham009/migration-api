import React from 'react'
import propTypes from 'prop-types'
import { FormControl, Select, MenuItem } from '@mui/material'
//*** styles ***
import { useTheme } from 'react-jss';
import { ThemeProvider, createTheme } from '@mui/material/styles'
import { createUseStyles } from 'react-jss';
import { CustomDropdownStyles, ThemeOverrides } from 'assets/styles/components/FormFields/customDropdown.styles'
const useStyles = createUseStyles(CustomDropdownStyles)


function CustomDropdown({ variant = "standard", id, items, value, onChange }) {
    const systemTheme = useTheme()
    const theme = createTheme(ThemeOverrides(systemTheme))
    const classes = useStyles()

    return (
        <FormControl className={classes.formControl} fullWidth>
            <ThemeProvider theme={theme}>
                <Select
                    id={id}
                    variant={variant}
                    className={classes.select}
                    value={value}
                    onChange={onChange}
                >
                    {items.map(item => (
                        <MenuItem key={item.id} className={classes.selectMenuItem} value={item.value}>
                            {item.text}
                        </MenuItem>
                    ))}
                </Select>
            </ThemeProvider>
        </FormControl>
    )
}


CustomDropdown.propTypes = {
    variant: propTypes.oneOf(["filled", "outlined", "standard"]),
    id: propTypes.string,
    items: propTypes.arrayOf(propTypes.object).isRequired,
    value: propTypes.string,
    onChange: propTypes.func
}


export default React.memo(CustomDropdown)