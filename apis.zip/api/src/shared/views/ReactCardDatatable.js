import React from 'react'
import { Container } from '@mui/material';
import ReactTable from 'components/DataTable'
//*** components ***
import Card from "components/Card"
import CardBody from "components/Card/CardBody"


function ReactCardDatatable({ columns, data, loading, pageCount, PageSizeList, fetchData, extraFooterContent }) {
    return (
        <Container maxWidth="xl">
            <Card style={{ marginTop: 100 }}>
                <CardBody>
                    <ReactTable
                        columns={columns}
                        data={data}
                        fetchData={fetchData}
                        loading={loading}
                        pageCount={pageCount}
                        PageSizeList={PageSizeList}
                        extraFooterContent={extraFooterContent}
                    />
                </CardBody>
            </Card>
        </Container>
    )
}

export default React.memo(ReactCardDatatable)