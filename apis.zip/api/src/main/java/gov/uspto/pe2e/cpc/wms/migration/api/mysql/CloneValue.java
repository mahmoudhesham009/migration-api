package gov.uspto.pe2e.cpc.wms.migration.api.mysql;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "CLONE_VALUE")
public class CloneValue {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name="id")
	private int id;
	@Column(name="FORM_ID")
	private String formId;
	@Column(name="FIELD_ID")
	private String fieldId;
	@Column(name="VALUE")
	private String value;
	@Column(name="JOB_ID")
	private int jobId;
}
