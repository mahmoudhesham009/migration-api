package gov.uspto.pe2e.cpc.wms.migration.api.mysql;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CloneValueRepository extends JpaRepository<CloneValue, Integer>{

	@Query(value="SELECT * FROM CLONE_VALUE WHERE JOB_ID=:jobId", nativeQuery=true)
	List<CloneValue> getByJobId(Integer jobId);

	@Query(value="SELECT * FROM CLONE_VALUE WHERE FORM_ID=:formId AND FIELD_ID=:fieldId AND JOB_ID=:jobId", nativeQuery=true)
	CloneValue getCloneValueByFormIdAndFieldIdAndJobId(String formId, String fieldId, int jobId);
}
