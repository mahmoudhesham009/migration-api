import { memo } from 'react'
import PropTypes from 'prop-types'
import { CircularProgress } from '@mui/material'
// *** Icons ***
import SpecialIcon from '@mui/icons-material/RotateRight';
// *** styles ***
import { createUseStyles } from 'react-jss'
import styles from 'assets/styles/components/spinner.styles'
const useStyles = createUseStyles(styles)

function Spinner({ type, size }) {
    const classes = useStyles();

    switch (type) {
        case "special-icon":
            return <SpecialIcon className={classes.spinnerIcon} />
        default:
            return <CircularProgress size={size} className={classes.spinnerProgress} />
    }
}

export default memo(Spinner)


Spinner.propTypes = {
    type: PropTypes.oneOf(["special-icon"]),
    size: PropTypes.number
}