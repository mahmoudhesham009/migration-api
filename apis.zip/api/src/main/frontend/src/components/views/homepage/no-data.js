import { memo, useMemo } from 'react'
import { Alert } from '@mui/material'

function NoData() {

  const alertSx = useMemo(() => {
    return {
      padding: "0px 8px",
      "& .MuiAlert-message": {
        width: "-webkit-fill-available",
        padding: "4px 0"
      }
    }
  }, [])

  return (
    <Alert
      icon={false}
      variant="standard"
      severity='warning'
      sx={alertSx}
    >
      No Data
    </Alert>
  )
}

export default memo(NoData)
