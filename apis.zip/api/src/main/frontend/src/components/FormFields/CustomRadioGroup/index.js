import React, { Component } from 'react'
import classNames from 'classnames'
import PropTypes from 'prop-types'
import { RadioGroup, Radio, FormControlLabel, FormControl, FormLabel, FormHelperText } from '@mui/material'
import _ from 'lodash';
// *** styles ***
import commonStyles from 'assets/styles/components/FormFields/common.styles'
import withStyles from 'react-jss';

/**
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com>
 * @type {Predicate}
 * @param {{
 *  options: Array<Radio>;
 *  direction: "row" | "column";
 *  labelPlacement: "top" | "start" | "bottom" | "end";
 *  margin: "dense" | "normal" | "none"
 *  size: "small" | "medium" | "large"; 
 * }} props Props for the component
 */
class CustomRadioGroup extends Component {

  constructor(props) {
    super(props)

    this.state = {
      options: [],
      error: false,
      disabled: false,
      value: ""
    }
  }

  static getDerivedStateFromProps(props, state) {
    return {
      options: props.options,
      error: props.error,
      disabled: props.disabled,
      value: props.value
    }
  }


  shouldComponentUpdate(nextProps, nextState) {
    const isEqual = _(nextProps.options).differenceWith(this.state.options, _.isEqual).isEmpty();
    if (
      nextProps.error !== this.state.error ||
      nextProps.disabled !== this.state.disabled ||
      nextProps.value !== this.state.value ||
      !isEqual
    )
      return true
    else return false
  }


  render() {

    const { name, formLabel, defaultValue, direction, labelPlacement, helperText, options, error, disabled, fullWidth, margin, required, size, variant, value, onChange, classes } = this.props

    // console.log("=================================================");
    // console.log(`%c --- Render Custom Radio Group ${name}`, "color: #f5991a");
    // console.log("error: ", error);
    // console.log("=================================================");

    return (
      <FormControl
        error={error}
        disabled={disabled}
        fullWidth={fullWidth}
        margin={margin}
        size={size}
        variant={variant}
        required={required}
      >
        <FormLabel
          classes={{
            error: classes.themeColorError,
            focused: classes.formLabelFocused
          }}
        >
          {formLabel}
        </FormLabel>
        <RadioGroup
          row={direction === "row"}
          name={name}
          defaultValue={defaultValue}
          onChange={onChange}
          value={value}
        >
          {options.map(({ id, label, value }) => (
            <FormControlLabel
              key={`form-control-label-${id}`}
              labelPlacement={labelPlacement}
              label={label}
              value={value}
              classes={{ error: classes.themeColorError }}
              control={
                <Radio
                  size={size}
                  classes={{
                    root: classNames(classes.themeColorPrimary, {
                      [classes.themeColorError]: error,
                    }),
                  }}
                />
              }
            />
          ))}
        </RadioGroup>
        {helperText && (
          <FormHelperText
            sx={{ ml: 0, mr: 0 }}
            classes={{
              root: classes.helperText,
              error: classes.themeColorError
            }}
          >
            {helperText}
          </FormHelperText>
        )}
      </FormControl>
    )
  }
}



CustomRadioGroup.defaultProps = {
  direction: "row",
  labelPlacement: "end",
  margin: "normal",
  size: "small",
  required: false
}

CustomRadioGroup.propTypes = {
  name: PropTypes.string.isRequired,
  formLabel: PropTypes.string.isRequired,
  defaultValue: PropTypes.string,
  helperText: PropTypes.string,
  options: PropTypes.arrayOf(PropTypes.object).isRequired,
  error: PropTypes.bool,
  disabled: PropTypes.bool,
  fullWidth: PropTypes.bool,
  direction: PropTypes.oneOf(["row", "column"]),
  labelPlacement: PropTypes.oneOf(["top", "start", "bottom", "end"]),
  margin: PropTypes.oneOf(['dense', 'normal', 'none']),
  size: PropTypes.oneOf(['small', 'medium', 'large'])
}

export default withStyles(commonStyles)(CustomRadioGroup)