import React from 'react'
import PropTypes from "prop-types";
import classNames from "classnames";
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import Input from '@mui/material/Input'
import FormHelperText from '@mui/material/FormHelperText'
// *** Icons ***
import Clear from '@mui/icons-material/Clear'
// *** styles ***
import styles from "assets/styles/components/FormFields/customInput.style";
import commonStyles from 'assets/styles/components/FormFields/common.styles'
import { createUseStyles } from 'react-jss'
const useClasses = createUseStyles(styles)
const useCommonStyles = createUseStyles(commonStyles)



/**
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com> 
 * @type {Predicate}
 * @param {{
 *  margin: "dense" | "normal" | "none";
 *  size: "small" | "medium" | "large"; 
 * }} props Props for the component 
 */
function CustomInput({
    name, value, onChange, onBlur, labelText, error, readOnly, helperText, fullWidth, margin, disabled, shrink, tabIndex, size, multiline, minRows, maxRows, required
}) {
    const classes = useClasses()
    const commonClasses = useCommonStyles()

    const labelClasses = classNames({ [" " + commonClasses.themeColorError]: error, });
    const underlineClasses = classNames(classes.underline, { [classes.underlineError]: error });
    const marginTop = classNames({ [classes.marginTop]: labelText === undefined });


    // console.log(`%c --- Render Custom Input ${name}`, "color: #f52147");
    // console.log("=================================================");

    return (
        <FormControl
            className={classes.formControl}
            variant="standard"
            error={error}
            fullWidth={fullWidth}
            margin={margin}
            disabled={disabled}
            size={size}
            // required={required}
        >
            {labelText !== undefined ? (
                <InputLabel htmlFor={name} className={classes.labelRoot + labelClasses} shrink={shrink}>
                    {required ? `${labelText} *` : labelText}
                </InputLabel>
            ) : null}

            <Input
                id={name}
                // name={name}
                // value={value}
                // onChange={onChange}
                // onBlur={onBlur}
                style={{ backgroundColor: Boolean(readOnly) && "rgb(37 35 32 / 7%)" }}
                error={Boolean(error || readOnly)}
                readOnly={readOnly}
                inputProps={{ 
                    tabIndex: tabIndex && tabIndex,
                    name: name,                    
                    value: value,
                    onChange: onChange,
                    onBlur: onBlur
                }}
                classes={{
                    root: marginTop,
                    disabled: classes.disabled,
                    underline: underlineClasses,
                    error: error ? commonClasses.themeColorError : ""
                }}
                multiline={multiline}
                minRows={minRows}
                maxRows={maxRows}
            />
            {error ? (<Clear className={classes.feedback + " " + commonClasses.themeColorError} />) : null}
            {
                helperText &&
                <FormHelperText
                    classes={{
                        root: classNames(commonClasses.helperText, { [commonClasses.themeColorSuccess]: !error }),
                        error: commonClasses.themeColorError
                    }}
                >
                    {helperText}
                </FormHelperText>
            }

        </FormControl>
    )
}





CustomInput.defaultProps = {
    margin: "normal",
    size: "small",
    fullWidth: false,   
    required: false 
}

CustomInput.propTypes = {
    labelText: PropTypes.node,
    id: PropTypes.string,
    error: PropTypes.bool,
    readOnly: PropTypes.bool,
    helperText: PropTypes.string,
    fullWidth: PropTypes.bool,
    margin: PropTypes.oneOf(['dense', 'normal', 'none']),
    disable: PropTypes.bool,
    shrink: PropTypes.bool,
    tabIndex: PropTypes.string,
    size: PropTypes.oneOf(['small', 'medium', 'large']),
    name: PropTypes.string,
    value: PropTypes.string,
    required: PropTypes.bool,
    onChange: PropTypes.func,
    onBlur: PropTypes.func,
};


export default React.memo(CustomInput)
