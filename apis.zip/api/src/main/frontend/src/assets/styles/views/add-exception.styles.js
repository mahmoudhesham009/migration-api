import { transparentize } from 'polished';

const FindProcessCardStyles = theme => ({
    findProcessRoot: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100%",
        width: "100%",
        "& .find-process-card": {
            // padding: 25,
            maxWidth: 600,
            minHeight: 350,
            "& .find-process-card-icon-wrapper": {
                display: "inline-block",
                marginLeft: 20,
                "& svg": {
                    color: theme.colors.white
                }
            },
            "& h3.find-process-card-title": {
                fontSize: 22,
                textTransform: "uppercase",
                textAlign: "center",
                fontWeight: 600
            },
            "& .alert-section": {
                marginTop: 15
            },
            "& .form-wrapper": {
                display: "flex",
                alignItems: "center",
                height: "calc(300px - 38.0938px - 15px - 25.6719px - 10px)",
                width: "100%",
                "&.with-alert-open-above": {
                    height: "calc(300px - 38.0938px - 15px - 25.6719px - 10px - 50.0156px)",
                },
                "& form": {
                    flex: "0 0 50%",
                    position: "relative",
                    "& button": {
                        marginTop: 15
                    },
                }
            }
        }
    },
    userEntryErrorNumber: {
        backgroundColor: transparentize(0.8, theme.colors.danger[0]),
        color: theme.colors.danger[0],
        padding: "5px 10px",
        borderRadius: 60,
        whiteSpace: "nowrap",
        maxWidth: 275,
        overflow: "hidden",
        textOverflow: "ellipsis",
        display: "block",
        float: "right",
        marginTop: -5,
        marginLeft: 5

    }
})

export { FindProcessCardStyles }
