import { transparentize } from "polished"
import extraCommonDTStyles from 'assets/styles/shared/commonDatatableComponents.styles';
import { commonModalRootStyles, commonModalBoxStyles } from 'assets/styles/shared/commonModalStyles'


const DeploymentListStyles = theme => ({
    accordionSummaryRoot: {
        "& p": {
            flexShrink: 0,
            // backgroundColor: theme.colors.primary[0],
            borderRadius: 60,
            padding: "8px 16px",
            "& button": {
                pointerEvents: "none",
                verticalAlign: "middle",
                padding: 0,
                marginRight: 8,
                // color: theme.colors.white
            },
            "& strong": {
                display: "inline-block",
                verticalAlign: "bottom",
                // color: theme.colors.white
            }
        }
    },
    InfoLabel: {
        display: "inline-block",
        padding: 15,
        marginBottom: 15,
        borderRadius: 3,
        backgroundImage: "linear-gradient(to left top, #003660, #005780, #007787, #009574);",
        position: "relative",
        "&:before": {
            content: "''",
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            borderRadius: 3,
            backgroundColor: transparentize(0.9, theme.colors.black),
        },
        "& h1": {
            color: theme.colors.white,
            position: "relative",
            zIndex: 1,
            fontSize: 24,
            maxWidth: 600,
            width: "fit-content",
            whiteSpace: "nowrap",
            textOverflow: "ellipsis",
            overflow: "hidden",
        }
    }
})

const AnalysisStyles = theme => ({
    analysis: {
        "& .loading-progress": {
            height: "calc(100vh - 64px - 48px - 35px - 25px) !important"
        },
        "& .deployment-list-container": {
            marginTop: "0px!important"
        },
        "& .page-controls": {
            marginBottom: 25,
            "& .add-exception-button": {
                backgroundColor: theme.colors.primary[0],
                paddingLeft: 6,
                paddingRight: 10,
                // marginBottom: 25,
                boxShadow: "unset",
                "& svg": {
                    verticalAlign: "middle",
                    marginTop: -3,
                    paddingRight: 5
                },
            }
        }
    }
})

const OldVariablesStyles = theme => ({
    oldVariables: {
        "& .top-actions-btn": {
            paddingLeft: 6,
            paddingRight: 10,
            boxShadow: "unset",
            "& svg": {
                verticalAlign: "middle",
                marginTop: -3
            },
            "&.add-old-variable-button": {
                backgroundColor: theme.colors.primary[0],
            },
        }
    },
    deleteOldVariablesBtn: {
        ...extraCommonDTStyles(theme).interactiveButton(theme.colors.rose[0]),
    }
})

const CreateNewOldVariableModalStyles = theme => ({
    createNewOldVariableModal: {
        ...commonModalRootStyles
    },
    modalBox: {
        ...commonModalBoxStyles(theme, '0px'),
        "& .create-new-old-variable-btn-wrapper": {
            marginTop: 25,
            "& button": {
                backgroundColor: theme.colors.primary[0],
            }
        },
    }
})

const AnalysisRootStyles = theme => ({
    analysisRoot: {
        paddingTop: 25,
        "& .card-icon-wrapper": {
            display: "inline-block",
            marginRight: 20,
            "& > div": {
                float: "right"
            }
        },
        "& .tabsBox": {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            marginBottom: 25
        },
        // "& .tabsContent": {            
        //     "& > div": {
        //         paddingTop: 15
        //     }            
        // },
    },
    tabsRoot: {
        "& button": {
            borderRadius: 60,
            minHeight: "40px !important",
            "&:not(:last-child)": {
                marginRight: 16,
            }
        },
        "&.analysisTab": {
            "& button:nth-child(1)": {
                backgroundColor: theme.colors.primary[0],
                color: theme.colors.white
            },
        },
        "&.oldVariablesTab": {
            "& button:nth-child(2)": {
                backgroundColor: theme.colors.primary[0],
                // backgroundColor: "#00695f",
                color: theme.colors.white
            }
        }
    },
    tabsIndicator: {
        display: "none!important"
    },
})

export default AnalysisRootStyles
export {
    DeploymentListStyles,
    AnalysisStyles,
    OldVariablesStyles,
    CreateNewOldVariableModalStyles
}
