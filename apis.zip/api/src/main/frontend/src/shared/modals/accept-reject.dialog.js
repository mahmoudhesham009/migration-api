import { memo } from 'react'
import PropTypes from 'prop-types';
import { Dialog, DialogActions, DialogContent, DialogTitle, Typography, Button } from "@mui/material";
// *** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/shared/acceptRejectDialog.styles';
const useStyles = createUseStyles(styles)

function PromptLeaving({ title, description, confirmButtonTitle, cancelButtonTitle, open, fullWidth, maxWidth, onClose, onAccept, onReject }) {
  const classes = useStyles()  

  return (
    <Dialog
      fullWidth={fullWidth}
      maxWidth={maxWidth}
      open={open}
      onClose={onClose}
    >
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <Typography>{description}</Typography>
      </DialogContent>
      <DialogActions>
        <Button
          variant="contained"
          className={classes.confirmButton}
          onClick={onAccept}
        >
          {confirmButtonTitle}
        </Button>
        <Button
          variant="outlined"
          className={classes.cancelButton}
          onClick={onReject}
        >
          {cancelButtonTitle}
        </Button>
      </DialogActions>
    </Dialog>
  )
}


PromptLeaving.defaultProps = {
  showDialog: false,
  maxWidth: "xs"
}

PromptLeaving.propTypes = {
  title: PropTypes.string.isRequired,
  description: PropTypes.oneOfType([PropTypes.string, PropTypes.array]).isRequired,
  confirmButtonTitle: PropTypes.string.isRequired,
  cancelButtonTitle: PropTypes.string.isRequired,
  open: PropTypes.bool,
  fullWidth: PropTypes.bool,
  maxWidth: PropTypes.oneOf(["xs", "xl", "sm", "md", "lg"]),
  onClose: PropTypes.func,
  onAccept: PropTypes.func,
  onReject: PropTypes.func
}

export default memo(PromptLeaving)