

const DynamicFormListStyles = theme => ({
    accordionSummaryRoot: {
        "& p": {
            flexShrink: 0, 
            backgroundColor: theme.colors.primary[0],
            borderRadius: 60, 
            padding: "8px 16px",
            "& button": {
                pointerEvents: "none",
                verticalAlign: "middle", 
                padding: 0, 
                marginRight: 8,
                color: theme.colors.white
            },
            "& strong": {
                display: "inline-block", 
                verticalAlign: "bottom",
                color: theme.colors.white
            }
        }
    }
})


export default DynamicFormListStyles