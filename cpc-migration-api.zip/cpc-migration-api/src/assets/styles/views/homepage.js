
import { darken } from 'polished';

const HomePageStyles = theme => ({
    viewFormListButton: {
        backgroundColor: theme.colors.primary[0],
        color: theme.colors.white,
        // "& svg": {
        //     marginRight: 5
        // },
        "&:hover": {
            backgroundColor: darken(0.1, theme.colors.primary[0]),
        }
    }
})


export default HomePageStyles