


const CustomDropdownStyles = theme => ({
    formControl: {
        "& > div:before": {
            borderBottomColor: `${theme.colors.gray[4]}!important`,
            borderBottomWidth: "1px !important"
        },
        "& > div:after": {
            borderBottomColor: `${theme.colors.primary[0]}!important`
        }
    },
    select: {
        color: theme.colors.gray[2],
        margin: "12px 0 0",
        fontSize: ".75rem",
        fontWeight: "400",
        lineHeight: "1.42857",
        letterSpacing: 0,
        textTransform: "uppercase",
        textDecoration: "none",
        "&:focus": {
            backgroundColor: "transparent !important"
        }
    },
    selectMenuItem: {
        clear: "both",
        color: theme.colors.gray[8],
        margin: "0 5px",
        display: "block",
        padding: "10px 20px",
        fontSize: 13,
        transition: "all 150ms linear",
        fontWeight: 400,
        lineHeight: 2,
        whiteSpace: "nowrap",
        borderRadius: 2,
        paddingRight: 30,
        "&:hover": {
            color: theme.colors.white,
            backgroundColor: `${theme.colors.primary[0]}!important`,
        }
    }
})


/** 
 * .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root.Mui-focused .MuiOutlinedInput-notchedOutline 
 * MuiOutlinedInput-notchedOutline css-1d3z3hw-MuiOutlinedInput-notchedOutline
 */

const ThemeOverrides = theme => ({
    components: {
        MuiSelect: {
            styleOverrides: {
                select: {
                    paddingBottom: 14,
                    "& + input + svg": {
                        transition: "all 200ms linear"
                    },
                    "&:focus": {
                        backgroundColor: "transparent"
                    }
                }
            }
        },
        MuiPopover: {
            styleOverrides: {
                root: {
                    "& > div + div": {
                        maxHeight: "266px !important",
                        "&::-webkit-scrollbar-track": {
                            "webkitBoxShadow": "inset 0 0 6px rgba(0, 0, 0, 0.3)",
                            "borderRadius": "60px",
                            "backgroundColor": "#F5F5F5"
                        },
                        "&::-webkit-scrollbar": {
                            "width": "6px",
                            "maxHeight": "6px",
                            "backgroundColor": "#F5F5F5"
                        },
                        "&::-webkit-scrollbar-thumb": {
                            "borderRadius": "60px",
                            "webkitBoxShadow": "inset 0 0 6px rgba(0, 0, 0, .1)",
                            "backgroundColor": "rgba(0, 0, 0, 0.3)"
                        }
                    }
                }
            }
        },
        MuiMenuItem: {
            styleOverrides: {
                root: {
                    "&.Mui-selected": {
                        color: theme.colors.white,
                        backgroundColor: `${theme.colors.primary[0]}!important`,
                        fontWeight: "bold"
                    }
                }
            }
        }
    }
})


export {
    CustomDropdownStyles,
    ThemeOverrides
}