
const MuiDatePickerStyles = theme => ({
    root: {
        "& label": {
            color: theme.colors.gray[3] + " !important",
            fontFamily: "inherit",
            fontWeight: "400",
            fontSize: "14px",
            lineHeight: "1.42857",
            letterSpacing: "unset",
        }
    },
    underline: {
        "&:hover:not($disabled):before,&:before": {
            borderColor: theme.colors.gray[4] + " !important",
            borderWidth: "1px !important"
        }
    },
    disabled: {
        "&:before": {
            backgroundColor: "transparent !important"
        }
    },
    marginTop: {
        marginTop: "16px"
    }
})


const defaultMaterialThemeStyles = theme => ({
    palette: {
        primary: {
            main: theme.colors.primary[0] + "!important"
        },
        secondary: {
            main: theme.colors.gray[3],
        },
        error: {
            main: theme.colors.danger[0]
        }
    },
    components: {
        MuiFormControl: {
            styleOverrides: {
                root: {
                    // backgroundColor: "#f0f!important",
                    // paddingBottom: "10px",
                }
            }
        },
        MuiPickersDay: {
            styleOverrides: {
                daySelected: {
                    color: theme.colors.white + "!important"
                }
            }
        },
    }
})


export {
    MuiDatePickerStyles,
    defaultMaterialThemeStyles
}