

const CommonFormFieldStyles = theme => ({
    formLabelFocused: {
        color: "rgba(0, 0, 0, 0.6)!important"
    },
    themeColorPrimary: {
        color: theme.colors.primary[0] + "!important"
    },
    themeColorError: {
        color: theme.colors.danger[0] + "!important"
    },
    helperText: {
        color: theme.colors.gray[4]
    },
})


export default CommonFormFieldStyles