import PropTypes from 'prop-types';
import * as Yup from 'yup'
import _ from 'lodash';


/**
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com>
 * @type {Predicate}
 * @param {object} apiResponse 
 * @returns Processed api that can we use it inside the react project
 */



export default function NewProcessApi(apiResponse) {

    const result = []

    apiResponse.map(({ DeploymentId, data }) => { // map on each deployment

        if (Array.isArray(data)) {
            if (data.length > 0) {
                const formData = []

                Object.keys(data[0]).map(taskKey => { // map on data tasks
                    const formContent = {}
                    const initialValues = {}
                    const validationSchema = {}
                    const formFields = []
                    const { formFieldList, ...props } = data[0][taskKey]

                    formFieldList.map(({ id, name, required, type, value, ...props }) => {
                        formFields.push({ id, name, required, type, value, ...props })

                        if (type === "boolean") {
                            _.assign(initialValues, { [id]: required ? true : Boolean(value) })
                            if (required) {
                                _.assign(validationSchema, { [id]: Yup.boolean().required("Required Field.") })
                            }
                        }
                        else {
                            _.assign(initialValues, { [id]: value })
                            if (required) {
                                _.assign(validationSchema, { [id]: Yup.string().required("Required Field.") })
                            }
                        }
                    })

                    _.assign(formContent, { initialValues: initialValues })
                    _.assign(formContent, { validationSchema: Yup.object(validationSchema) })
                    _.assign(formContent, { formFields: formFields })
                    _.assign(formContent, { formKey: taskKey, ...props })

                    formData.push(formContent)
                })

                result.push({ DeploymentId, formData })
            }
        }        
    })


    return result
}









// function ProcessApi(apiResponse) {

//     console.log("apiResponse: ", apiResponse);

//     const formData = []
//     Object.keys(apiResponse).map(taskKey => { // map root object that includes definition key objects
//         const formContent = {}
//         const initialValues = {}
//         const validationSchema = {}
//         const formFields = []
//         const { formMap, ...props } = apiResponse[taskKey]

//         Object.keys(apiResponse[taskKey].formMap).map(formMapKey => {
//             // destructure each taskKey and get formMap then map to generate form fields
//             apiResponse[taskKey].formMap[formMapKey].map(({ id, name, required, type, value, ...props }) => {
//                 formFields.push({ id, name, required, type, value, ...props })

//                 if (type === "boolean") {
//                     _.assign(initialValues, { [id]: required ? true : Boolean(value) })
//                     if (required) {
//                         _.assign(validationSchema, { [id]: Yup.boolean().required("Required Field.") })
//                     }
//                 }
//                 else {
//                     _.assign(initialValues, { [id]: value })
//                     if (required) {
//                         _.assign(validationSchema, { [id]: Yup.string().required("Required Field.") })
//                     }
//                 }
//             })
//         })

//         _.assign(formContent, { initialValues: initialValues })
//         _.assign(formContent, { validationSchema: Yup.object(validationSchema) })
//         _.assign(formContent, { formFields: formFields })
//         _.assign(formContent, { ...props })

//         formData.push(formContent)
//     })

//     return formData
// }


NewProcessApi.propTypes = {
    apiResponse: PropTypes.array.isRequired
}