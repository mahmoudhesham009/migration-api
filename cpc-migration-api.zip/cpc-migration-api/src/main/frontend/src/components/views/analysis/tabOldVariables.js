import makeData from 'data/makeData.analysisOldVariables'
import { memo, useState, useRef, useMemo, useCallback, useReducer } from 'react'
import axios from 'axios';
import classNames from 'classnames';
import { Button, Tooltip, IconButton, Stack } from '@mui/material'
import HtmlReactParser from 'html-react-parser';
import { useLocation } from 'react-router-dom';
import queryString from 'query-string';
// *** hooks ***
import { DT_FILTER_LBL_NUMBER_OF_RECORDS } from 'hooks/useFilterText'
//*** modals ***
import DeleteOldVariablesSuccessFailureModal from 'shared/modals/success-failure.modal';
import DeleteOldVariablesDialog from 'shared/modals/accept-reject.dialog';
import OldVariableModal from 'components/views/analysis/oldVariableModal'
// *** components ***
import Card from "components/Card"
import CardIcon from 'components/Card/CardIcon';
import CardBody from "components/Card/CardBody"
import CardFooter from 'components/Card/CardFooter';
import ReactTable from 'components/DataTable'
import InteractiveButton from 'components/FormFields/CustomButton/InteractiveButton';
// *** Icons ***
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import AssignmentIcon from '@mui/icons-material/Assignment';
import DeleteSweepRoundedIcon from '@mui/icons-material/DeleteSweepRounded';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
// *** styles ***
import { createUseStyles } from 'react-jss'
import { DataTableActionStyles } from 'assets/styles/components/datatable.styles'
import { OldVariablesStyles } from 'assets/styles/views/analysis.styles';
const useDTActionStyles = createUseStyles(DataTableActionStyles)
const useStyles = createUseStyles(OldVariablesStyles)



const extraCellWrapperStyles = {
  maxWidth: 100,
  whiteSpace: "nowrap",
  overflow: "hidden",
  textOverflow: "ellipsis",
}

const oldVariablesModalDataInitialState = { rowId: null, formId: null, fieldId: null, value: null }

const deleteOldVariablesStatusModalInitialState = {
  open: false,
  status: "",
  title: "",
  description: ""
}

const deleteOldVariablesInitialState = {
  open: false,
  loading: false,
  selectedID: null,
  selectedJobID: null,
  btnIsSuccess: null,
  statusModal: deleteOldVariablesStatusModalInitialState
}

const deleteOldVariablesReducer = (state = deleteOldVariablesInitialState, action) => {
  switch (action.type) {
    case "changeOpenState":
      return { ...state, open: action.payload }
    case "deleteOldVariables":
      return {
        ...state,
        open: true,
        selectedID: action.payload?.id,
        selectedJobID: action?.payload?.jobID
      }
    case "onAcceptDeleteOldVariables":
      return { ...state, loading: true, open: false }
    case "onRejectDeleteOldVariables":
      return {
        ...state,
        open: false,
        selectedID: null,
      }
    case "onSuccessDeleteOldVariables":
      return {
        ...state,
        loading: false,
        btnIsSuccess: true,
        statusModal: {
          open: true,
          status: "success",
          title: "Operation Complete",
          description: HtmlReactParser(`
              Old Variable for
                ID: <strong>${action.payload?.id}</strong>
              and
                jobID: <strong>${action.payload?.jobID}</strong>
              was deleted successfully.
          `)
        }
      }
    case "onFailureDeleteOldVariables":
      return {
        ...state,
        loading: false,
        btnIsSuccess: false,
        statusModal: {
          open: true,
          status: "fail",
          title: "Operation Fail",
          description: HtmlReactParser(
            `Fail to delete old variable for
                ID: <strong>${action.payload?.id}</strong>
              and 
                jobID: <strong>${action.payload?.jobID}</strong>.
            `)
        }
      }
    case "onCloseDeleteOldVariablesSuccessFailureModal":
      return {
        ...state,
        btnIsSuccess: null,
        selectedID: null,
        selectedJobID: null,
        statusModal: deleteOldVariablesStatusModalInitialState
      }
    default: return state
  }
}

function TabOldVariables() {
  const fetchIdRef = useRef(0)
  const dtActionClasses = useDTActionStyles()
  const classes = useStyles()
  const location = useLocation();
  const parsed = queryString.parse(location.search);
  /**
   * Reducers
   */
  const [delOldVariables, dispatchDelOldVariables] = useReducer(deleteOldVariablesReducer, deleteOldVariablesInitialState)
  /**
   * States
   */
  const [oldVariablesModalIsOpen, setOldVariablesModalIsOpen] = useState(false)
  const [oldVariablesModalData, setOldVariablesModalData] = useState(oldVariablesModalDataInitialState)
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)
  const [pageCount, setPageCount] = useState(0)


  // *************** CALLBACKS ******************
  const fetchData = useCallback(({ pageSize, pageIndex, filters }) => {

    // console.log("pageSize: ", pageSize)
    // console.log("pageIndex: ", pageIndex)
    // console.log("filters: ", filters)
    // console.log("---------------------")


    setLoading(true)
    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      const serverData = makeData(50)
      const fetchId = ++fetchIdRef.current
      setTimeout(() => {
        if (fetchId === fetchIdRef.current) {
          const startRow = pageSize * pageIndex
          const endRow = startRow + pageSize
          setData(serverData.slice(startRow, endRow))
          setPageCount(Math.ceil(serverData.length / pageSize))
          setLoading(false)
        }
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      // const body = {
      //     pageIndex: pageIndex,
      //     pageSize: pageSize,
      //     sortBy: [],
      //     filters: filters,
      //     columnOrder: [],
      //     hiddenColumns: []
      // }      
      const headers = { "Content-type": "application/json" }
      axios
        .get(`/api/clone/${parsed?.jobID}`, { headers })
        .then(response => {
          setLoading(false)
          setData(response.data)
          // setPageCount(response.data.pagination.pageCount)
        })
        .catch(error => {
          console.log("error: ", error);
          setLoading(false)
        })
    }
  }, [])

  const handleClickDeleteOldVariables = useCallback((id, jobID) => {
    dispatchDelOldVariables({ type: "deleteOldVariables", payload: { id, jobID } })
  }, [])

  const onAcceptDeleteOldVariables = useCallback((id, jobID) => {
    dispatchDelOldVariables({ type: "onAcceptDeleteOldVariables" })
    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      setTimeout(() => {
        // dispatchDelOldVariables({ type: "onFailureDeleteOldVariables", payload: { id, jobID } })
        dispatchDelOldVariables({ type: "onSuccessDeleteOldVariables", payload: { id, jobID } })
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      const headers = { "Content-type": "application/json" }
      axios
        .delete(`api/clone/delete/${id}`, { headers })
        .then(response => {
          dispatchDelOldVariables({ type: "onSuccessDeleteOldVariables", payload: { id, jobID } })
        })
        .catch(error => {
          console.log("error: ", error);
          dispatchDelOldVariables({ type: "onFailureDeleteOldVariables", payload: { id, jobID } })
        })
    }
  }, [])

  const onRejectDeleteOldVariables = useCallback(() => {
    dispatchDelOldVariables({ type: "onRejectDeleteOldVariables" })
  }, [])

  const onCloseDeleteOldVariablesSuccessFailureModal = useCallback(() => {
    dispatchDelOldVariables({ type: "onCloseDeleteOldVariablesSuccessFailureModal" })
    if (delOldVariables?.btnIsSuccess)
      fetchData({ pageSize: 10, pageIndex: 1, filters: [] })
  }, [delOldVariables?.btnIsSuccess])

  const handleClickOpenOldVariablesModal = useCallback(() => { setOldVariablesModalIsOpen(true) }, [])

  const handleClickEditOldVariables = useCallback((event) => {
    const formId = event.target.getAttribute("data-formid")
    const fieldId = event.target.getAttribute("data-fieldid")
    const value = event.target.getAttribute("data-value")
    const rowId = event.target.getAttribute("data-rowid")


    setOldVariablesModalData({ rowId, formId, fieldId, value })
    setOldVariablesModalIsOpen(true)

  }, [])


  const onCloseOldVariablesModal = useCallback((userCreateOneOldVariableSuccessfully) => {
    setOldVariablesModalIsOpen(false)
    setOldVariablesModalData(oldVariablesModalDataInitialState)

    if (userCreateOneOldVariableSuccessfully) {
      fetchData({
        pageSize: 10,
        pageIndex: 1,
        filters: []
      })
    }
  }, [])



  // *************** MEMOS ******************

  const columns = useMemo(() => {
    return [
      {
        Header: 'Form ID',
        id: "formId",
        sortable: true,
        accessor: 'formId',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText',
        extraCellWrapperStyles
      },
      {
        Header: 'Field ID',
        id: "fieldId",
        sortable: true,
        accessor: 'fieldId',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText',
        extraCellWrapperStyles
      },
      {
        Header: 'Value',
        id: "value",
        sortable: true,
        accessor: 'value',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText',
        extraCellWrapperStyles
      },
      {
        Header: '',
        id: 'actions',
        sortable: false,
        isRowActions: true,
        extraStyles: { zIndex: 1051 },
        extraHeaderStyles: { width: "100%", textAlign: "center", pointerEvents: "none" },
        Filter: () => <div className={dtActionClasses.hiddenFilter}></div>,
        accessor: ({ id, formId, fieldId, value, jobId }) => {

          const delOldVariablesBtnIsSuccess = Boolean(delOldVariables.selectedID === id && delOldVariables.btnIsSuccess)
          const delOldVariablesBtnIsLoading = Boolean(delOldVariables.selectedID === id && delOldVariables.loading)


          return (
            <Stack direction="row" spacing={1}>
              <div>
                <Tooltip
                  placement='left'
                  title={HtmlReactParser(`
                      <div style="text-align: center; padding: 10px 5px">
                        <span style="margin-bottom: 10px; display: inline-block">
                          Edit Old Variables
                        </span>
                        <br /> 
                        <span>
                          For ID: <span style="background: #ff9800; padding: 2px 5px; border-radius: 50px">${id}</span>
                        </span>
                        and
                        <div style="margin-top: 10px">
                          JobID: <span style="background: #ff9800 ; padding: 2px 5px; border-radius: 50px">${jobId}</span>
                        </div>
                      </div>
                  `)}
                >
                  <IconButton
                    data-rowid={id}
                    data-formid={formId}
                    data-fieldid={fieldId}
                    data-value={value}
                    className={classes.editOldVariableBtn}
                    onClick={handleClickEditOldVariables}
                  >
                    <EditIcon />
                  </IconButton>
                </Tooltip>
              </div>
              <div>
                <InteractiveButton
                  className={classNames(classes.deleteOldVariablesBtn, {
                    "success": delOldVariablesBtnIsSuccess,
                    "loading": delOldVariablesBtnIsLoading
                  })}
                  variant="round"
                  text="Delete Exception"
                  toolTipTitle={HtmlReactParser(`
                        <div style="text-align: center; padding: 10px 5px">
                          <span style="margin-bottom: 10px; display: inline-block">
                            Delete Old Variables
                          </span>
                          <br /> 
                          <span>
                            For ID: <span style="background: #f44336; padding: 2px 5px; border-radius: 50px">${id}</span>
                          </span>
                          and
                          <div style="margin-top: 10px">
                            JobID: <span style="background: #f44336; padding: 2px 5px; border-radius: 50px">${jobId}</span>
                          </div>
                        </div>
                    `)}
                  toolTipPlacement="left"
                  initialIcon={<DeleteSweepRoundedIcon />}
                  successIcon={<CheckIcon />}
                  failureIcon={<CloseIcon />}
                  loading={delOldVariablesBtnIsLoading}
                  success={delOldVariablesBtnIsSuccess}
                  failure={Boolean(delOldVariables.btnIsSuccess !== null && delOldVariables.selectedID === id && !delOldVariables.btnIsSuccess)}
                  buttonSuccessClass=""
                  circularProps={{ size: 47, classes: { root: "interactive-spinner" } }}
                  onClick={() => handleClickDeleteOldVariables(id, jobId)}
                  disabled={delOldVariables.loading}
                  // disabled={Boolean(migrationBtnSelectedID === id && migrationBtnIsLoading)}
                  containedClasses=""
                />
              </div>
            </Stack>
          )
        }
      }
    ]
  }, [classes.deleteOldVariablesBtn, classes.editOldVariableBtn, delOldVariables.btnIsSuccess, delOldVariables.loading, delOldVariables.selectedID, dtActionClasses.hiddenFilter])

  return (
    <div id="old-variables-tab" className={classes.oldVariables}>

      <OldVariableModal
        {...oldVariablesModalData}
        jobID={parsed?.jobID}
        open={oldVariablesModalIsOpen}
        onClose={onCloseOldVariablesModal}
      />

      <DeleteOldVariablesDialog
        title="Confirm Delete Old Variable"
        description={HtmlReactParser(`
              Would you like to delete old variable for 
                ID: <strong>${delOldVariables.selectedID}</strong>
              and
                JobID: <strong>${delOldVariables.selectedJobID}</strong>
              ?
            `)}
        confirmButtonTitle="Yes"
        cancelButtonTitle="No"
        open={delOldVariables.open}
        onClose={() => dispatchDelOldVariables({ type: "changeOpenState", payload: false })}
        onAccept={() => onAcceptDeleteOldVariables(delOldVariables.selectedID, delOldVariables.selectedJobID)}
        onReject={onRejectDeleteOldVariables}
        fullWidth
      />


      <DeleteOldVariablesSuccessFailureModal
        {...delOldVariables.statusModal}
        onCloseModal={onCloseDeleteOldVariablesSuccessFailureModal}
      />

      <Button
        variant="contained"
        className="top-actions-btn add-old-variable-button"
        onClick={handleClickOpenOldVariablesModal}
      >
        <span>
          <AddIcon />
          Add Old Variable
        </span>
      </Button>

      <Card style={{ marginTop: 100 }}>
        <div className="card-icon-wrapper">
          <CardIcon color="primary">
            <AssignmentIcon sx={{ color: "#fff" }} />
          </CardIcon>
        </div>
        <CardBody>
          <ReactTable
            columns={columns}
            data={data}
            fetchData={fetchData}
            loading={loading}
            pageCount={pageCount}
            PageSizeList={[10, 20, 25, 50, 75, 100]}
          // extraFooterContent={extraFooterContent}
          />
        </CardBody>
        <CardFooter />
      </Card>

    </div>
  )
}

export default memo(TabOldVariables)
