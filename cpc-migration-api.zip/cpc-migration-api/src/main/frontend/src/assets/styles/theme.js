

// TODO: hexToRgb Converter
const hexToRgb = input => {
    input = input + "";
    input = input.replace("#", "");
    let hexRegex = /[0-9A-Fa-f]/g;
    if (!hexRegex.test(input) || (input.length !== 3 && input.length !== 6)) {
        throw new Error("input is not a valid hex color.");
    }
    if (input.length === 3) {
        let first = input[0];
        let second = input[1];
        let last = input[2];
        input = first + first + second + second + last + last;
    }
    input = input.toUpperCase();
    let first = input[0] + input[1];
    let second = input[2] + input[3];
    let last = input[4] + input[5];
    return (
        parseInt(first, 16) +
        ", " +
        parseInt(second, 16) +
        ", " +
        parseInt(last, 16)
    );
};
// ############# FONTS #############
const fonts = {
    default: {
        fontFamily: "inherit",
        fontWeight: "300",
        lineHeight: "1.5em"
    },
    comfortaa: {
        fontFamily: "Comfortaa, cursive"
    }
}
// ############# TRANSITIONS #############
const transitions = [
    "all 0.33s cubic-bezier(0.685, 0.0473, 0.346, 1)"
]
// ############# COLORS #############
const colors = {
    black: "#000",
    white: "#fff",    
    // primary: ["#9c27b0", "#ab47bc", "#8e24aa", "#af2cc5"],
    primary: ["#003660", "#3D4B7F", "#006189", "#426493"],
    warning: ["#ff9800", "#ffa726", "#fb8c00", "#ffa21a"],
    danger: ["#f44336", "#ef5350", "#e53935", "#f55a4e"],
    success: ["#4caf50", "#66bb6a", "#43a047", "#5cb860"],
    info: ["#00acc1", "#26c6da", "#00acc1", "#00d3ee"],
    rose: ["#e91e63", "#ec407a", "#d81b60", "#eb3573"],
    gray: [
        "#999", //0
        "#777", //1
        "#3C4858", //2
        "#AAAAAA", //3
        "#D2D2D2", //4
        "#DDD", //5
        "#b4b4b4", //6
        "#555555", //7
        "#333", //8
        "#a9afbb", //9
        "#eee", //10
        "#e7e7e7", //11
        "#e5e5e5", //12
        "#e4e4e4", //13
        "#e0e0e0", // 14            
        "#ccc", // 15
        "#f5f5f5", // 16
        "#495057", // 17
        "#212121", // 18
        "#c8c8c8", // 19
        "#505050" //20
    ]
}
// ############# SHADOWS #############
const shadows = {
    default:
        "0 10px 20px -12px rgba(" +
        hexToRgb(colors.black) +
        ", 0.42), 0 3px 20px 0px rgba(" +
        hexToRgb(colors.black) +
        ", 0.12), 0 8px 10px -5px rgba(" +
        hexToRgb(colors.black) +
        ", 0.2)"
    ,
    primary:
        "0 4px 20px 0 rgba(" +
        hexToRgb(colors.black) +
        ",.14), 0 7px 10px -5px rgba(" +
        hexToRgb(colors.primary[0]) +
        ",.4)"
    ,
    info:
        "0 4px 20px 0 rgba(" +
        hexToRgb(colors.black) +
        ",.14), 0 7px 10px -5px rgba(" +
        hexToRgb(colors.info[0]) +
        ",.4)"
    ,
    success:
        "0 4px 20px 0 rgba(" +
        hexToRgb(colors.black) +
        ",.14), 0 7px 10px -5px rgba(" +
        hexToRgb(colors.success[0]) +
        ",.4)"
    ,
    warning:
        "0 4px 20px 0 rgba(" +
        hexToRgb(colors.black) +
        ",.14), 0 7px 10px -5px rgba(" +
        hexToRgb(colors.warning[0]) +
        ",.4)"
    ,
    danger:
        "0 4px 20px 0 rgba(" +
        hexToRgb(colors.black) +
        ",.14), 0 7px 10px -5px rgba(" +
        hexToRgb(colors.danger[0]) +
        ",.4)"
    ,
    rose:
        "0 4px 20px 0 rgba(" +
        hexToRgb(colors.black) +
        ",.14), 0 7px 10px -5px rgba(" +
        hexToRgb(colors.rose[0]) +
        ",.4)"
}
// ############# CARD #############
const card = {
    defaultStyling: {
        display: "inline-block",
        position: "relative",
        width: "100%",
        margin: "25px 0",
        boxShadow: "0 1px 4px 0 rgba(" + hexToRgb(colors.black) + ", 0.14)",
        borderRadius: "3px",
        color: "rgba(" + hexToRgb(colors.black) + ", 0.87)",
        background: colors.white
    },
    cardHeader: {
        defaultStyling: {
            margin: "-20px 15px 0",
            borderRadius: "3px",
            padding: "15px"
        },
        success: {
            background:
                "linear-gradient(60deg, " + colors.success[1] + ", " + colors.success[2] + ")",
            boxShadow: shadows.success
        },
        warning: {
            background:
                "linear-gradient(60deg, " + colors.warning[1] + ", " + colors.warning[2] + ")",
            boxShadow: shadows.warning
        },
        danger: {
            background:
                "linear-gradient(60deg, " + colors.danger[1] + ", " + colors.danger[2] + ")",
            boxShadow: shadows.danger
        },
        info: {
            background:
                "linear-gradient(60deg, " + colors.info[1] + ", " + colors.info[2] + ")",
            boxShadow: shadows.info
        },
        primary: {
            background:
                "linear-gradient(60deg, " + colors.primary[1] + ", " + colors.primary[2] + ")",
            boxShadow: shadows.primary
        },
        rose: {
            background:
                "linear-gradient(60deg, " + colors.rose[1] + ", " + colors.rose[2] + ")",
            boxShadow: shadows.rose
        },
        white: {
            background:
                "linear-gradient(60deg, " + colors.white + ", " + colors.gray[13] + ")",
        },
    },
    cardActions: {
        margin: "0 20px 10px",
        paddingTop: "10px",
        borderTop: "1px solid " + colors.gray[10],
        height: "auto",
        ...fonts.default
    },
}


const theme = {
    hexToRgb,
    fonts,
    transitions,
    colors,
    shadows,
    card
}

export default theme