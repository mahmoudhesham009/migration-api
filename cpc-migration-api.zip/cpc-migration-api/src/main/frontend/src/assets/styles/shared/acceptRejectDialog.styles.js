import { lighten, darken } from 'polished';

const AcceptRejectDialogStyles = theme => ({
    confirmButton: {
        backgroundColor: theme.colors.primary[0],
        "&:hover": {
            backgroundColor: lighten(0.1, theme.colors.primary[0]),
        }
    },
    cancelButton: {
        borderColor: theme.colors.primary[0],
        color: theme.colors.primary[0],
        "&:hover": {
            borderColor: darken(0.1, theme.colors.primary[0]),
            color: darken(0.1, theme.colors.primary[0]),
        }
    }
})


export default AcceptRejectDialogStyles