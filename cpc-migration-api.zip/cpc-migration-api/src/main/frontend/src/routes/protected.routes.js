import _ from 'lodash';
// *** Views ***
import Homepage from 'views/homepage';
import Analysis from 'views/analysis';
import Exception from 'views/exceptions';
import AddException from 'views/add-exception';
import Reports from 'views/Reports';
import Logs from 'views/logs';
import ErrorPage from 'views/errorPage';
// *** icons ***
import HomepageIcon from '@mui/icons-material/Home';
import ExceptionsIcon from '@mui/icons-material/BugReport';
import AnalysisIcon from '@mui/icons-material/DynamicForm';
import LogsIcon from '@mui/icons-material/Description';
import SummarizeIcon from '@mui/icons-material/Summarize';


const privateRoutes = [
    {        
        id: "homepage",
        title: "Home",
        index: true,
        path: "/",
        icon: <HomepageIcon />,
        element: <Homepage />
    },
    {
        id: "analysis",
        title: "Analysis",
        path: "/analysis",
        icon: <AnalysisIcon />,
        element: <Analysis />
    },
    {        
        id: "exceptions",
        title: "Exceptions",
        path: "/exceptions",
        icon: <ExceptionsIcon />,
        element: <Exception />
    },
    {
        id: "add-exception",
        title: "Add Exception",
        path: "/add-exception",        
        icon: <ExceptionsIcon />,
        element: <AddException />
    },
    {
        id: "logs",
        title: "Logs",
        path: "/logs",
        icon: <LogsIcon />,
        element: <Logs />
    },
    {
        id: "report",
        title: "report",
        path: "/reports",
        icon: <SummarizeIcon />,
        element: <Reports />
    },
    {
        id: "error-page",
        path: "*",
        element: <ErrorPage errorNumber={404} errorMessage="This page could not be found" />
    }
]


const pageRoutesJSON = {}
privateRoutes.map(({ path, ...props }) => (_.assign(pageRoutesJSON, { [path]: { path, ...props } })))


export { pageRoutesJSON }
export default privateRoutes
