import namor from 'namor'
import { range } from './common';


const newRecord = () => {
    return {
        id: Math.floor(Math.random() * 1000),
        jobId: Math.floor(Math.random() * 1000),
        processId: namor.generate({ words: 1, saltLength: 0 }),
        processName: namor.generate({ words: 1, saltLength: 0 }),
        projectNum: `#${namor.generate({ words: 0, saltLength: 5 })}`,
        details: `Hello <strong>My Name is: </strong> <br /> Na'oum Haddad`

        // details: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    }
}


export default function makeData(...lens) {
    const makeDataLevel = (depth = 0) => {
        const len = lens[depth]
        return range(len).map(d => {
            return {
                ...newRecord(),
                subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined,
            }
        })
    }

    return makeDataLevel()
}
