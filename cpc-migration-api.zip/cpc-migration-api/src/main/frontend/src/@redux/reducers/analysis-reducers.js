import { SET_EXPANDED_PARENT, SET_EXPANDED_CHILD, SET_NAV_BEHAVIOR } from '@redux/types/analysis-types'

const initialState = {
  expandedParent: false,
  expandedChild: false
}

const analysisReducer = (state = initialState, action) => {
  switch (action.type) {
    case SET_EXPANDED_PARENT:
      return { ...state, expandedParent: action.payload }
    case SET_EXPANDED_CHILD:
      return { ...state, expandedChild: action.payload }
    default: return state
  }
}

export default analysisReducer
