import { configureStore } from '@reduxjs/toolkit';
import { persistStore, persistReducer } from 'redux-persist'
import storage from 'redux-persist/lib/storage' // defaults to localStorage for web
import thunk from 'redux-thunk';
import logger from 'redux-logger'
import rootReducer from '@redux/rootReducer'
import { batchedSubscribe } from 'redux-batched-subscribe'
import _ from 'lodash';


const debounceNotify = _.debounce(notify => notify());
const persistConfig = {
    key: "root",
    storage
}

const _persistReducer = persistReducer(persistConfig, rootReducer);


export const store = configureStore({
    reducer: _persistReducer,
    middleware: [thunk, logger],
    devTools: process.env.NODE_ENV !== 'production',
    enhancers: [batchedSubscribe(debounceNotify)],
})

export const persistor = persistStore(store)
