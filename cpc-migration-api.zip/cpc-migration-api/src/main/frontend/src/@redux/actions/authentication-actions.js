import { LOGIN, LOGOUT } from '@redux/types/authentication-types'

export const Login = () => {
    return {
        type: LOGIN
    }
}

export const Logout = () => {
    return {
        type: LOGOUT
    }
}