
import { SET_EXPANDED_PARENT, SET_EXPANDED_CHILD } from '@redux/types/analysis-types'


export const ChangeExpandedParentAccordion = (id) => {
  return {
      type: SET_EXPANDED_PARENT,
      payload: id
  }
}


export const ChangeExpandedChildAccordion = (id) => {
  return {
      type: SET_EXPANDED_CHILD,
      payload: id
  }
}
