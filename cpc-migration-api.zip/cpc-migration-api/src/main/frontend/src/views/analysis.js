import { memo, useState, useLayoutEffect, useMemo, useCallback } from 'react'
import { Link, useLocation, useSearchParams } from 'react-router-dom';
import { Container, Tabs, Tab } from '@mui/material'
import queryString from 'query-string';
// *** shared ***
import a11yProps from 'shared/modals/a11yProps'
// *** views ***
import ErrorPage from 'views/errorPage';
// *** components ***
import TabAnalysis from 'components/views/analysis/tabAnalysis'
import TabOldVariables from 'components/views/analysis/tabOldVariables'
// *** icons ***
import DynamicFormIcon from '@mui/icons-material/DynamicForm';
import ShapeLineIcon from '@mui/icons-material/ShapeLine';
// *** styles ***
import classNames from 'classnames'
import { createUseStyles } from 'react-jss'
import styles from 'assets/styles/views/analysis.styles';
const useStyles = createUseStyles(styles)

function Analysis() {
  const classes = useStyles()
  const location = useLocation();
  const parsed = queryString.parse(location.search);
  const [searchParams, setSearchParams] = useSearchParams();

  const [activeTab, setActiveTab] = useState(0)
  // ***************** MEMOS ***************** 
  const analysisIcon = useMemo(() => { return <DynamicFormIcon /> }, [])
  const oldVariablesIcon = useMemo(() => { return <ShapeLineIcon /> }, []) 
  const errorPageExtraJSX = useMemo(() => { return <Link to="/">Back to Homepage</Link> }, [])
  const tabsClasses = useMemo(() => {
    return {
      root: classNames(classes.tabsRoot, {
        "analysisTab": activeTab === 0,
        "oldVariablesTab": activeTab === 1,
      }),
      indicator: classes.tabsIndicator
    }
  }, [activeTab, classes.tabsRoot, classes.tabsIndicator])
  // ***************** CALLBACKS ***************** 
  const handleChange = useCallback((event, newValue) => {
    setActiveTab(newValue)

    switch (newValue) {
      case 0:
        searchParams.set("activeTab", "analysis");
        setSearchParams(searchParams, {
          state: {
            singleProcess: location.state?.singleProcess
          }
        })
        break;
      case 1:
        searchParams.set("activeTab", "oldVariables");
        setSearchParams(searchParams, {
          state: {
            singleProcess: location.state?.singleProcess
          }
        })
        break;
      default:
        break;
    }
  }, [location.state?.singleProcess, searchParams, setSearchParams])



  useLayoutEffect(() => {    
    if (parsed?.jobID) {
      switch (parsed?.activeTab) {
        case "analysis":
          setActiveTab(0)
          break;
        case "oldVariables":
          setActiveTab(1)
          break;
        default:
          setActiveTab(0)
          break;
      }
    }
  }, [parsed?.activeTab, parsed?.jobID]) 


  if (!Boolean(parsed?.jobID)) return (
    <ErrorPage
      errorMessage="Oops!&nbsp;&nbsp;<strong>[ Job ID ]</strong>&nbsp;&nbsp;is not present."
      extraJSX={errorPageExtraJSX}
    />
  )
  else return (
    <div className={classes.analysisRoot}>
      <Container maxWidth="xl">
        <div className="tabsBox">
          <Tabs
            value={activeTab}
            classes={tabsClasses}
            onChange={handleChange}
          >
            <Tab
              label="Analysis"
              iconPosition="start"
              icon={analysisIcon}
              disableRipple
              {...a11yProps(0)}
            />
            <Tab
              label="Old Variables"
              iconPosition="start"
              icon={oldVariablesIcon}
              disableRipple
              disabled={!location.state?.singleProcess}
              {...a11yProps(1)}
            />
          </Tabs>
        </div>

        <div className="tabsContent">
          {activeTab === 0 && <TabAnalysis />}
          {activeTab === 1 && <TabOldVariables />}
        </div>
      </Container>
    </div>
  )
}

export default memo(Analysis)
