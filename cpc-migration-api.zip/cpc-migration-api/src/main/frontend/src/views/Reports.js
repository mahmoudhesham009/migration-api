import React, { useMemo } from "react";
import { useState } from "react";
import { useCallback } from "react";
// *** icons ***
import DynamicFormIcon from "@mui/icons-material/DynamicForm";
import ShapeLineIcon from "@mui/icons-material/ShapeLine";
// *** styles ***
import classNames from "classnames";
import { createUseStyles } from "react-jss";
import { ReportStyles } from "assets/styles/views/reports.styles";
import { Container, Tab, Tabs } from "@mui/material";
import AuditReport from "components/views/reports/AuditReport";
import JobsReport from "components/views/reports/JobsReport";
const useStyles = createUseStyles(ReportStyles);
const Reports = () => {
  const classes = useStyles();
  const [activeTab, setActiveTab] = useState(0);

  // ***************** MEMOS *****************
  const analysisIcon = useMemo(() => {
    return <DynamicFormIcon />;
  }, []);
  const oldVariablesIcon = useMemo(() => {
    return <ShapeLineIcon />;
  }, []);
  const tabsClasses = useMemo(() => {
    return {
      root: classNames(classes.tabsRoot, {
        analysisTab: activeTab === 0,
        oldVariablesTab: activeTab === 1,
      }),
      indicator: classes.tabsIndicator,
    };
  }, [activeTab, classes.tabsRoot, classes.tabsIndicator]);
  // ***************** CALLBACKS *****************
  const handleChange = useCallback(
    (event, newValue) => {
      setActiveTab(newValue);
    },
    [activeTab]
  );

  return (
    <div className={classes.analysisRoot}>
      <Container maxWidth="xl">
        <div className="tabsBox">
          <Tabs value={activeTab} classes={tabsClasses} onChange={handleChange}>
            <Tab
              label="Audit Report"
              iconPosition="start"
              icon={analysisIcon}
              disableRipple
            />
            <Tab
              label="Jobs Report"
              iconPosition="start"
              icon={oldVariablesIcon}
              disableRipple
            />
          </Tabs>
        </div>

        <div className="tabsContent">
          {activeTab === 0 && <AuditReport />}
          {activeTab === 1 && <JobsReport />}
        </div>
      </Container>
    </div>
  );
};

export default Reports;
