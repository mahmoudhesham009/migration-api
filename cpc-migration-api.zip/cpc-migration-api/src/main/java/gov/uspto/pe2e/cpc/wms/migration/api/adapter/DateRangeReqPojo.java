package gov.uspto.pe2e.cpc.wms.migration.api.adapter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DateRangeReqPojo {

	String toString;
	String fromString;
	Date from;
	Date to;
	
	
	/*void setFrom(Data from) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-YY",Locale.US);
		this.from=sdf.parse(this.fromString);
	}*/
	
	
}
