package gov.uspto.pe2e.cpc.wms.migration.api.mysql;

import java.util.Date;
import java.util.List;

import javax.persistence.Tuple;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ReportsRepository extends JpaRepository<MigrationJob, Integer>{

	@Query(value="select pi.name uuid, pi.PROJECTNUM, \r\n" + 
			"CASE WHEN  pi.status = 200 THEN 'Successful'\r\n" + 
			"   ELSE 'Failed' END  status,\r\n" + 
			"   oi.STARTEDTIME original_process_start_date\r\n" + 
			"from MIGRATION_JOB mj\r\n" + 
			"inner join PROCESSMIGRATIONINFO pi on mj.id=pi.jobid\r\n" + 
			"inner join ORIGINALPROCESSINFO oi on pi.ORIGINALPROCESSID=oi.PROCESSINSTANCEID\r\n" + 
			"where mj.CREATED_DATE BETWEEN :dFrom and :dTo", nativeQuery=true)
	List<Tuple> getProcessReport(Date dFrom,Date dTo);
	
	
	
	@Query(value="select mj.ID, mj.CREATED_DATE, count(CASE WHEN  pi.status = 200 THEN 1\r\n" + 
			"   ELSE null END ) success,  count(pi.id) total from MIGRATION_JOB mj\r\n" + 
			"inner join PROCESSMIGRATIONINFO pi on mj.id=pi.jobid\r\n" + 
			"where mj.CREATED_DATE BETWEEN :dFrom and :dTo\r\n" + 
			"GROUP BY mj.ID, mj.CREATED_DATE", nativeQuery=true)
	List<Tuple> getJobsReport(Date dFrom,Date dTo);
}
