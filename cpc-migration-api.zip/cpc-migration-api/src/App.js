import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from "react-jss";
// *** views ***
import Homepage from 'views/homepage';
import DynamicFormList from 'views/dynamic-form-list';
import ErrorPage from 'views/errorPage';
// *** styles ***
import theme from 'assets/styles/theme'
import 'normalize.css'
import 'assets/styles/css/global.css'
// *** Hooks ***
import useWindowWidth from 'hooks/useWindowWidth'
// *** Contexts ***
const WindowContext = React.createContext()

function App() {
  const windowWidth = useWindowWidth()

  return (
    <>
      <ThemeProvider theme={theme}>
        <WindowContext.Provider value={{ windowWidth }}>

          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Homepage />} />
              <Route path="/dynamic-form-list" element={<DynamicFormList />} />
              <Route path="*" element={<ErrorPage errorNumber="404" errorMessage="This page could not be found" />} />
            </Routes>
          </BrowserRouter>

        </WindowContext.Provider>
      </ThemeProvider>
    </>
  );
}





export { WindowContext }
export default App;