import { memo } from 'react'
import { CircularProgress, Typography } from '@mui/material';
// *** styles ***
import { createUseStyles } from 'react-jss';
const useStyles = createUseStyles(theme => ({
  "@keyframes animateDots": {
    to: {
      clipPath: "inset(0 -1ch 0 0)"
    }
  },
  loadingProgress: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column",
    height: "100vh",
    "& .progress": {
      width: "220px!important",
      height: "220px!important",
      "& svg": {
        color: theme.colors.primary[0],
        fontSize: "50px"
      }
    },
    "& p": {
      fontSize: 25,
      // fontFamily: "monospace",      
      display: "inline-block",
      fontWeight: "bold",
      marginTop: 50,
      clipPath: "inset(0 3ch 0 0)",
      "-webkit-animation": "$animateDots .9s steps(4) infinite",
      animation: "$animateDots .9s steps(4) infinite",
    }
  }
}))


function LoadingSpinner() {
  const classes = useStyles()

  return (
    <div className={classes.loadingProgress}>
      <CircularProgress className="progress" />
      <Typography>Please wait . . .</Typography>
    </div >
  )
}

export default memo(LoadingSpinner)