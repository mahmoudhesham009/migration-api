import React from 'react'
import { Field } from 'formik';
import { FormControlLabel, Tooltip } from '@mui/material';
import { Switch } from 'formik-mui';
// *** styles ***
import { styled } from '@mui/material/styles';
import { useTheme } from 'react-jss'
import { iOSCustomSwitcherStyles } from 'assets/styles/components/FormFields/customSwitch.styles'


const IOSSwitch = styled(({ checked, sysTheme, ...props }) => (
    <Tooltip title={Boolean(checked) ? "checked" : "unchecked"}>
        <span>
            <Switch
                sx={{ mr: 1 }}
                focusVisibleClassName=".Mui-focusVisible"
                checked={checked}
                // disableRipple
                {...props}
            />
        </span>
    </Tooltip>
))(iOSCustomSwitcherStyles);


function IOSCustomSwitcher({ name, label, checked, disabled, onChange }) {
    const theme = useTheme()

    // console.log("=================================================");
    // console.log(`%c --- Render IOSCustomSwitcher: ${name}`, "color: #8aa1ef");
    // console.log("=================================================");

    return (
        <FormControlLabel
            label={label}
            sx={{ m: 0 }}
            control={
                <Field
                    disabled={disabled}
                    type="checkbox"
                    name={name}
                    label={label}
                    checked={checked}
                    sysTheme={theme}
                    component={IOSSwitch}
                    onChange={onChange}
                />
            }
        />
    )
}

export default React.memo(IOSCustomSwitcher)