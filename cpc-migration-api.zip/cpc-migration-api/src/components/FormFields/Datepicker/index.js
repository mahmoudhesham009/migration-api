import 'date-fns';
import React, { useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import { TextField } from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
//*** styles ***
import { ThemeProvider, createTheme } from '@mui/material/styles'
import { MuiDatePickerStyles, defaultMaterialThemeStyles } from 'assets/styles/components/FormFields/datepicker.styles'
import { createUseStyles, useTheme } from 'react-jss';
const useStyles = createUseStyles(MuiDatePickerStyles)



function Datepicker({ label, value, textfieldVariant = "standard", format, helperText, fullWidth, onDateChange, startAdornment, extraThemeComponents = {} }) {

    const [selectedDate, setSelectedDate] = useState(new Date());
    const classes = useStyles()
    const systemTheme = useTheme()
    const theme = createTheme({
        palette: {
            ...defaultMaterialThemeStyles(systemTheme).palette
        },
        components: {
            ...defaultMaterialThemeStyles(systemTheme).components,
            ...extraThemeComponents
        }
    });

    useEffect(() => {
        if ((new Date(value) !== "Invalid Date") && !isNaN(new Date(value)))
            setSelectedDate(value)
    }, [value])


    const handleDateChange = (date) => {
        setSelectedDate(date)
        onDateChange(date)
    }

    return (
        <ThemeProvider theme={theme}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                    className={classes.root}
                    label={label}
                    value={selectedDate}
                    inputFormat={format}
                    onChange={handleDateChange}
                    InputProps={{
                        startAdornment,
                        classes: {
                            root: classes.marginTop,
                            disabled: classes.disabled,
                            underline: classes.underline
                        }
                    }}
                    renderInput={props => (
                        <TextField
                            fullWidth={fullWidth}
                            variant={textfieldVariant}
                            helperText={helperText}
                            {...props}
                        />
                    )}
                />
            </LocalizationProvider>
        </ThemeProvider>
    )
}


Datepicker.propTypes = {
    label: PropTypes.string.isRequired,
    value: PropTypes.string,
    textfieldVariant: PropTypes.oneOf(["filled", "outlined", "standard"]),
    format: PropTypes.string,
    helperText: PropTypes.string,
    fullWidth: PropTypes.bool,
    onDateChange: PropTypes.func
}

export default React.memo(Datepicker)