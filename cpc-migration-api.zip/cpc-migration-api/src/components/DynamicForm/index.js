import React from 'react'
import _ from 'lodash';
import PropTypes from 'prop-types';
import { Formik, Form, Field } from 'formik';
import { Grid } from '@mui/material'
// *** components ***
import CustomInput from 'components/FormFields/CustomInput'
import CustomButton from 'components/FormFields/CustomButton'
import IOSSwitch from 'components/FormFields/CustomSwitch/IOSSwitch'
import CustomRadioGroup from 'components/FormFields/CustomRadioGroup'
import { Stack } from '@mui/system';





const DynamicForm = React.forwardRef(({ formId, initialValues, validationSchema, onSubmit, formFields }, ref) => {
    return (
        <Formik
            innerRef={ref}
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={values => onSubmit(values, { formId })}
        >
            {
                formik => {
                    return (
                        <Form onSubmit={formik.handleSubmit}>
                            <Grid container columnSpacing={3} rowSpacing={1}>

                                {formFields.map(({ id, name, type, value, options, required }, Idx) => {
                                    switch (type) {
                                        case "readonly":
                                        case "readonly-text":
                                        case "text":
                                        case "multi-line-text":

                                            const otherTextfieldProps = {}

                                            if ((type === "readonly" || type === "readonly-text") && value === "") {
                                                _.assign(otherTextfieldProps, { shrink: false })
                                            }

                                            if (type === "multi-line-text") {
                                                _.assign(otherTextfieldProps, {
                                                    multiline: true,
                                                    minRows: 4, maxRows: 6
                                                })
                                            }

                                            return (
                                                <Grid key={`grid-${name}`} item md={6}>
                                                    <Field name={name}>
                                                        {({ field: { name, value, onChange, onBlur }, form, meta: { touched, error } }) => (
                                                            <CustomInput
                                                                key={`form-textField-${id}`}
                                                                labelText={name}
                                                                error={Boolean(formik.touched?.[id] && formik.errors?.[id])}
                                                                helperText={formik.touched?.[id] && formik.errors?.[id] ? formik.errors?.[id] : ""}
                                                                fullWidth
                                                                margin="normal"
                                                                disabled={formik.isSubmitting}
                                                                readOnly={Boolean(type === "readonly" || type === "readonly-text")}
                                                                // name={name}
                                                                // value={value}
                                                                // onChange={onChange}
                                                                // onBlur={onBlur}
                                                                {...formik.getFieldProps(id)}
                                                                {...otherTextfieldProps}
                                                            />
                                                        )}
                                                    </Field>
                                                </Grid>
                                            )
                                        case "radio-buttons":
                                            return (
                                                <Grid key={`grid-${name}`} item md={6}>
                                                    <Field name={id}>
                                                        {({ field, form, meta }) => {
                                                            return (
                                                                <CustomRadioGroup
                                                                    name={id}
                                                                    value={field.value}
                                                                    formLabel={name}
                                                                    direction="row"
                                                                    size="small"
                                                                    labelPlacement='end'
                                                                    margin="normal"
                                                                    fullWidth
                                                                    defaultValue={value}
                                                                    disabled={formik.isSubmitting}
                                                                    onChange={field.onChange}
                                                                    options={options.map(({ id, name }) => ({ id, label: name, value: id }))}
                                                                    error={Boolean(meta.touched && meta.error)}
                                                                    helperText={Boolean(meta.touched && meta.error) ? meta.error : ""}
                                                                />
                                                            )
                                                        }}
                                                    </Field>
                                                </Grid>
                                            )
                                        case "boolean":
                                            return (
                                                <Grid key={`grid-${name}`} item md={6}>
                                                    <Field name={id}>
                                                        {({ field, form, meta }) => (
                                                            <IOSSwitch
                                                                key={`form-switch-${id}`}
                                                                name={id}
                                                                label={name}
                                                                checked={Boolean(field.value)}
                                                                disabled={formik.isSubmitting}
                                                                onChange={field.onChange}
                                                            />
                                                        )}
                                                    </Field>
                                                </Grid>
                                            )
                                        default:
                                            break;
                                    }
                                })}
                            </Grid>



                            <Stack direction="row" spacing={3}>
                                <CustomButton
                                    type="submit"
                                    innerContent={formik.isSubmitting ? "Please Wait..." : "Save"}
                                    variant='contained'
                                    color="primary"
                                    disabled={formik.isSubmitting}
                                />

                                <CustomButton
                                    type="reset"
                                    innerContent="Reset"
                                    variant='outlined'
                                    color="primary"
                                    disabled={formik.isSubmitting}
                                />
                            </Stack>



                            {/* <h1>Values</h1>
                            <pre>{JSON.stringify(formik.values, null, 2)}</pre> */}
                        </Form>
                    )
                }
            }
        </Formik>
    )
})

DynamicForm.propTypes = {
    initialValues: PropTypes.object.isRequired,
    validationSchema: PropTypes.object,
    onSubmit: PropTypes.func.isRequired
}


export default React.memo(DynamicForm)