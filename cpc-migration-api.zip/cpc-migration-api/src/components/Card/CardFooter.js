import React from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
// *** styles ***
import styles from "assets/styles/components/Card/cardFooter.styles";
import { createUseStyles } from 'react-jss';
const useStyles = createUseStyles(styles)


function CardFooter({ className, children, plain, profile, stats, chart }) {
  const classes = useStyles();  
  const cardFooterClasses = classNames({
    [classes.cardFooter]: true,
    [classes.cardFooterPlain]: plain,
    [classes.cardFooterProfile]: profile,
    [classes.cardFooterStats]: stats,
    [classes.cardFooterChart]: chart,
    [className]: className !== undefined
  })
  
  return (
    <div className={cardFooterClasses}>
      {children}
    </div>
  );
}

CardFooter.propTypes = {
  className: PropTypes.string,
  plain: PropTypes.bool,
  profile: PropTypes.bool,
  stats: PropTypes.bool,
  chart: PropTypes.bool,
  children: PropTypes.node
};

export default React.memo(CardFooter)