import namor from 'namor'


const range = len => {
    const arr = []
    for (let i = 0; i < len; i++) {
        arr.push(i)
    }
    return arr
}



const randomDates = [
    "2022-12-12T15:51:25.589+00:00",
    "2022-09-28T15:51:25.589+00:00",
    "2021-01-11T15:51:25.589+00:00",
    "2019-02-12T15:51:25.589+00:00",
    "2025-03-05T15:51:25.589+00:00",
    "2022-04-04T15:51:25.589+00:00",
    "2017-05-02T15:51:25.589+00:00",
    "2016-06-12T15:51:25.589+00:00",
    "2003-07-12T15:51:25.589+00:00",
    "2008-08-11T15:51:25.589+00:00",
    "2013-09-12T15:51:25.589+00:00",
    "2015-010-18T15:51:25.589+00:00",
    "2012-11-16T15:51:25.589+00:00",
    "2012-12-21T15:51:25.589+00:00",
    "2016-01-22T15:51:25.589+00:00",
    "2015-02-25T15:51:25.589+00:00",
    "2014-03-28T15:51:25.589+00:00",
    "2013-04-31T15:51:25.589+00:00",
    "2012-05-16T15:51:25.589+00:00",
]




const newCustomerRecord = () => {
    return {
        id: Math.floor(Math.random() * 1000),
        processName: namor.generate({ words: 1, saltLength: 0 }),
        fromDate: randomDates[Math.floor(Math.random() * (randomDates.length - 1))],
        toDate: randomDates[Math.floor(Math.random() * (randomDates.length - 1))],
        createdDate: randomDates[Math.floor(Math.random() * (randomDates.length - 1))],
        modifyDate: randomDates[Math.floor(Math.random() * (randomDates.length - 1))],
        status: Math.floor(Math.random() * 1000) % 2 === 0 ? "In Progress" : "Finished"
    }
}



export default function makeData(...lens) {
    const makeDataLevel = (depth = 0) => {
        const len = lens[depth]
        return range(len).map(d => {
            return {
                ...newCustomerRecord(),
                subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined,
            }
        })
    }

    return makeDataLevel()
}