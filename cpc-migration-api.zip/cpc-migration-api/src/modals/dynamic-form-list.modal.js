import React from 'react'
import { Modal, Box, Typography, Button } from '@mui/material';
//*** Icons ***
import FailureIcon from '@mui/icons-material/Cancel';
import SuccessIcon from '@mui/icons-material/CheckCircle';
//*** styles ***
import { createUseStyles } from 'react-jss';
const useStyles = createUseStyles(theme => ({
    modal: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center"
    },
    modalBox: {
        maxWidth: 500,
        width: "100%",
        padding: "25px 0px",
        borderRadius: 6,
        backgroundColor: theme.colors.white,
        "& .modal-check-icon": {
            display: "flex",
            justifyContent: "center",
            marginBottom: 20,
            "& svg": {
                fontSize: 75,
                color: theme.colors.primary[0],
            }
        },
        "& .modal-title": {
            fontSize: 24,
            textAlign: "center",
            fontWeight: 600,
            marginBottom: 20
        },
        "& .modal-description": {
            fontSize: 16,
            textAlign: "center",
        },
        "& .modal-close-button-wrapper": {
            display: "flex",
            justifyContent: "center",
            marginTop: 25,
            "& button": {
                background: theme.colors.primary[0],
                color: theme.colors.white + "!important",
                fontWeight: 500,
                padding: "10px 25px"
            }
        },
        "@media(max-width: 570px)": {
            maxWidth: "100%",
            width: "calc(100% - 30px)",
            margin: "0 auto"
        },
    }
}))

function SaveModal({ open, status, title, description, onCloseModal }) {
    const classes = useStyles()

    return (
        <Modal 
            open={open} 
            onClose={onCloseModal}
            className={classes.modal}
        >
            <Box sx={{ boxShadow: 24 }} className={classes.modalBox}>
                <div className="modal-check-icon">
                    {status === "success" ? <SuccessIcon /> : <FailureIcon />}
                </div>
                <Typography variant='h3' component='h3' className="modal-title">{title}</Typography>
                <Typography className="modal-description">{description}</Typography>
                <div className="modal-close-button-wrapper">
                    <Button onClick={onCloseModal}>
                        Close
                    </Button>
                </div>
            </Box>
        </Modal>
    )
}

export default SaveModal