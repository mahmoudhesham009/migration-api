import namor from 'namor'
import { range } from './common';



const newRecord = () => {
  return {
    id: Math.floor(Math.random() * 1000),
    jobId: namor.generate({ words: 1, saltLength: Math.floor((Math.random() * (10 - 4)) + 4) }),
    formId: namor.generate({ words: 1, saltLength: Math.floor((Math.random() * (10 - 4)) + 4) }),
    fieldId: namor.generate({ words: 1, saltLength: Math.floor((Math.random() * (10 - 4)) + 4) }),
    value: namor.generate({ words: 1, saltLength: Math.floor((Math.random() * (10 - 4)) + 4) })
  }
}



export default function makeData(...lens) {

  const makeDataLevel = (depth = 0) => {
    const len = lens[depth]
    return range(len).map(d => {
      const isSingleProcess = Math.floor(Math.random() * 1000) % 2 === 0
      return {
        ...newRecord(isSingleProcess),
        subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined,
      }
    })
  }

  return makeDataLevel()
}
