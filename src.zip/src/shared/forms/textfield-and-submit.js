import { memo, forwardRef, useMemo } from 'react'
import PropTypes from 'prop-types'
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
// *** components ***
import CustomInput from 'components/FormFields/CustomInput';
import CustomButton from 'components/FormFields/CustomButton';
import Spinner from 'components/spinner'



const TextFieldAndSubmit = forwardRef(({ name, labelText, buttonTxt, startIcon, required, disabled, isSubmitting, onSubmit }, ref) => {

  const initialValues = useMemo(() => {
    return { [name]: "" }
  }, [name])

  const __validation = useMemo(() => {
    if (required) return {
      validationSchema: Yup.object({
        [name]: Yup.string().required("Required Field!")
      })
    }

    return {}
  }, [required, name])


  return (
    <Formik
      innerRef={ref}
      initialValues={initialValues}
      onSubmit={onSubmit}
      {...__validation}
    >
      {({
        handleSubmit,
        ...formik
      }) => {
        return (
          <Form onSubmit={handleSubmit}>
            <Field name={name}>
              {({ field, form, meta }) => (
                <CustomInput
                  labelText={labelText}
                  // error={error}
                  // helperText={helperText}
                  error={Boolean(formik.touched?.[name] && formik.errors?.[name])}
                  helperText={formik.touched?.[name] && formik.errors?.[name] ? formik.errors?.[name] : ""}
                  fullWidth
                  margin="none"
                  disabled={disabled}
                  {...formik.getFieldProps(name)}
                />
              )}
            </Field>
            <CustomButton
              type="submit"
              innerContent={buttonTxt}
              variant='contained'
              color="primary"
              disabled={disabled}
              startIcon={isSubmitting ? <Spinner size={20} /> : startIcon}
            />
          </Form>
        )
      }}
    </Formik>
  )
});



TextFieldAndSubmit.defaultProps = {
  name: "",
  labelText: "",
  buttonTxt: "",
  required: false,
  disabled: false,
  isSubmitting: false,
}

TextFieldAndSubmit.propTypes = {
  name: PropTypes.string.isRequired,
  labelText: PropTypes.string.isRequired,
  buttonTxt: PropTypes.string.isRequired,
  startIcon: PropTypes.object,
  required: PropTypes.bool,
  disabled: PropTypes.bool,
  isSubmitting: PropTypes.bool,
  onSubmit: PropTypes.func.isRequired
}


export default memo(TextFieldAndSubmit)
