const ReportStyles = (theme) => ({
  analysisRoot: {
    paddingTop: 25,
    "& .card-icon-wrapper": {
      display: "inline-block",
      marginRight: 20,
      "& > div": {
        float: "right",
      },
    },
    "& .tabsBox": {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      marginBottom: 25,
    },
    // "& .tabsContent": {
    //     "& > div": {
    //         paddingTop: 15
    //     }
    // },
  },
  tabsRoot: {
    "& button": {
      borderRadius: 60,
      minHeight: "40px !important",
      "&:not(:last-child)": {
        marginRight: 16,
      },
    },
    "&.analysisTab": {
      "& button:nth-child(1)": {
        backgroundColor: theme.colors.primary[0],
        color: theme.colors.white,
      },
    },
    "&.oldVariablesTab": {
      "& button:nth-child(2)": {
        backgroundColor: theme.colors.primary[0],
        // backgroundColor: "#00695f",
        color: theme.colors.white,
      },
    },
  },
  tabsIndicator: {
    display: "none!important",
  },
});

export { ReportStyles };
