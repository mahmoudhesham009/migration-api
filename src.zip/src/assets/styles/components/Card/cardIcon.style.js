const CardIconStyle = theme => ({
    cardIcon: {
        borderRadius: "3px",
        backgroundColor: theme.colors.gray[0],
        padding: "15px",
        marginTop: "-20px",
        marginRight: "15px",
        float: "left"
    },
    warningCardHeader: {
        ...theme.card.cardHeader.warning
    },
    successCardHeader: {
        ...theme.card.cardHeader.success
    },
    dangerCardHeader: {
        ...theme.card.cardHeader.danger
    },
    infoCardHeader: {
        ...theme.card.cardHeader.info
    },
    primaryCardHeader: {
        ...theme.card.cardHeader.primary
    },
    roseCardHeader: {
        ...theme.card.cardHeader.rose
    },
    whiteCardHeader:{
        ...theme.card.cardHeader.white,
        "& svg": {
            color: theme.colors.primary[0]
        }
    }
})

export default CardIconStyle;
