import { memo, useState } from 'react'
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { CircularProgress, Button, Fab, Tooltip, Collapse } from '@mui/material';
//*** Styles ***
import { createUseStyles } from 'react-jss';
import { InteractiveButtonStyles } from 'assets/styles/components/FormFields/customButton.styles';
const useStyles = createUseStyles(InteractiveButtonStyles)



function InteractiveButton({ variant, text, toolTipTitle, toolTipPlacement, disableTooltip, initialIcon, successIcon, failureIcon, loading, success, failure, buttonSuccessClass, circularProps, onClick, containedClasses, ...other }) {
    const classes = useStyles()
    return (
        <Tooltip
            title={loading ? 'in Progress...' : toolTipTitle}
            placement={toolTipPlacement}
            disableHoverListener={disableTooltip}
        >
            {variant === "round" ?
                <div className={classes.wrapper}>
                    <Fab
                        onClick={onClick}
                        className={classNames({
                            [buttonSuccessClass]: success,
                        })}
                        {...other}
                    >
                        {success ? successIcon : failure ? failureIcon : initialIcon}
                    </Fab>
                    {loading && <CircularProgress className={classes.fabProgress} {...circularProps} />}
                </div>
                :
                <div className={classes.wrapper}>
                    <Button
                        variant="contained"
                        onClick={onClick}
                        className={classNames(containedClasses, {
                            [buttonSuccessClass]: success
                        })}
                        {...other}
                    >
                        {loading ? <CircularProgress {...circularProps} /> : success ? successIcon : initialIcon}
                        <span style={{ paddingRight: 10 }}></span>
                        {text}
                    </Button>
                </div>}
        </Tooltip>
    )
}

InteractiveButton.defaultProps = {
    disableTooltip: false
}

InteractiveButton.propTypes = {
    variant: PropTypes.oneOf(["round", "contained"]).isRequired,
    text: PropTypes.string,
    toolTipTitle: PropTypes.any,
    disableTooltip: PropTypes.bool,
    toolTipPlacement: PropTypes.oneOf([
        "center",
        "top-start",
        "top",
        "top-end",
        "left-start",
        "left",
        "left-end",
        "right-start",
        "right",
        "right-end",
        "bottom-start",
        "bottom",
        "bottom-end"
    ]),
    initialIcon: PropTypes.element,
    successIcon: PropTypes.element,
    loading: PropTypes.bool,
    success: PropTypes.bool,
    buttonSuccessClass: PropTypes.oneOfType([PropTypes.string, PropTypes.object]).isRequired,
    circularProps: PropTypes.object
}


export default memo(InteractiveButton)
