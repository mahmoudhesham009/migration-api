import { memo, useMemo, useState, useRef } from 'react'
import { Alert, Modal, Box, Stack, Typography, Button, IconButton, Slide } from '@mui/material';
import { Formik, Form, Field } from 'formik'
import * as Yup from 'yup'
import axios from 'axios';
import { motion } from 'framer-motion'
import _ from 'lodash'
// *** components ***
import Spinner from 'components/spinner'
import CustomInput from 'components/FormFields/CustomInput'
// *** icons ***
import CloseIcon from '@mui/icons-material/Close';
// *** styles ***
import classNames from 'classnames'
import { createUseStyles } from 'react-jss'
import { CreateNewOldVariableModalStyles } from 'assets/styles/views/analysis.styles';
import { useCallback } from 'react';
const useStyles = createUseStyles(CreateNewOldVariableModalStyles)


const alertInitialState = { open: false, severity: "success", message: "" }
// const initialValues = { formId: "", fieldId: "", value: "" }
const validationSchema = Yup.object({
  formId: Yup.string().required("Required Field."),
  fieldId: Yup.string().required("Required Field."),
  value: Yup.string().required("Required Field.")
})

function CreateNewOldVariableModal({ jobID, rowId, formId, fieldId, value, open, onClose }) {

  const classes = useStyles()
  const formikRef = useRef(null)

  const [loading, setLoading] = useState(false)
  const [alert, setAlert] = useState(alertInitialState)
  const [userCreateOneOldVariableSuccessfully, setUserCreateOneOldVariableSuccessfully] = useState(false)


  const action = useMemo(() => { return (rowId && formId && fieldId) ? "edit" : "create" }, [rowId, fieldId, formId])

  const initialValues = useMemo(() => {
    return {
      formId: action === "edit" ? formId : "",
      fieldId: action === "edit" ? fieldId : "",
      value: action === "edit" ? value : "",
    }
  }, [action, fieldId, formId, value])


  const onSubmit = useCallback(({ formId, fieldId, value }, { setSubmitting }) => {

    setLoading(true)

    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      setTimeout(() => {
        setLoading(false)
        setSubmitting(false)
        setAlert({ open: true, severity: "success", message: "A new variable was created successfully." })
        setUserCreateOneOldVariableSuccessfully(true)
      }, 2000)

      // setTimeout(() => {
      //   setLoading(false)
      //   setSubmitting(false)
      //   setAlert({ open: true, severity: "error", message: "Could not create a new variable." })
      //   setUserCreateOneOldVariableSuccessfully(false)
      // }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      const headers = { "Content-type": "application/json" }
      let body = { jobId: jobID, formId, fieldId, value }

      if (action === "edit")
        _.assign(body, { id: rowId })

      axios
        .post("/api/clone/save", body, { headers })
        .then(response => {
          setAlert({ open: true, severity: "success", message: action === "edit" ? "Variable updated successfully." : "A new variable was created successfully." })
          setUserCreateOneOldVariableSuccessfully(true)
        })
        .catch(error => {
          console.log("error: ", error);
          setAlert({ open: true, severity: "error", message: action === "edit" ? "Could not update the variable." : "Could not create a new variable." })
        })
        .finally(() => {
          setLoading(false)
          setSubmitting(false)
        })
    }

  }, [action, jobID, rowId])


  const handleClickCloseModal = useCallback(() => {
    setLoading(false)
    setAlert(alertInitialState)
    onClose(userCreateOneOldVariableSuccessfully)
    setUserCreateOneOldVariableSuccessfully(false)
  }, [onClose, userCreateOneOldVariableSuccessfully])

  return (
    <Modal open={open} className={classes.createNewOldVariableModal}>
      <Slide
        in={open}
        timeout={200}
        direction='up'
        unmountOnExit
      >
        <Box sx={{ boxShadow: 24 }} className={classes.modalBox}>
          {alert.open && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Alert
                variant="outlined"
                severity={alert.severity}
                className="alert-section"
              >
                {alert.message}
              </Alert>
            </motion.div>
          )}


          <div className="top-section">
            <Typography variant='h3' component='h3' className="modal-title">
              {action === "edit" ? "Update Old Variable" : "Add New Old Variable"}
            </Typography>

            <IconButton onClick={handleClickCloseModal}>
              <CloseIcon />
            </IconButton>
          </div>


          <Formik
            innerRef={formikRef}
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
          >
            {formik => {
              return (
                <Form>
                  <Stack direction="column" spacing={2}>

                    <Field name="formId">
                      {({ field, form, meta: { touched, error } }) => (
                        <CustomInput
                          labelText="Form ID"
                          error={Boolean(touched && error)}
                          helperText={Boolean(touched && error) ? error : ""}
                          required
                          fullWidth
                          margin="normal"
                          disabled={formik.isSubmitting}
                          {...field}
                        />
                      )}
                    </Field>

                    <Field name="fieldId">
                      {({ field, form, meta: { touched, error } }) => (
                        <CustomInput
                          labelText="Field ID"
                          error={Boolean(touched && error)}
                          helperText={Boolean(touched && error) ? error : ""}
                          required
                          fullWidth
                          margin="normal"
                          disabled={formik.isSubmitting}
                          {...field}
                        />
                      )}
                    </Field>

                    <Field name="value">
                      {({ field, form, meta: { touched, error } }) => (
                        <CustomInput
                          labelText="Value"
                          error={Boolean(touched && error)}
                          helperText={Boolean(touched && error) ? error : ""}
                          required
                          fullWidth
                          margin="normal"
                          disabled={formik.isSubmitting}
                          {...field}
                        />
                      )}
                    </Field>

                    <div className={classNames("create-new-old-variable-btn-wrapper", {
                      "edit-action": action === "edit"
                    })}>
                      <Button
                        type="submit"
                        variant="contained"
                        disabled={userCreateOneOldVariableSuccessfully}
                      >
                        <span>
                          {loading && <Spinner size={17} />}
                          {action === "edit" ? "Update" : "Create"}
                        </span>
                      </Button>
                    </div>

                  </Stack>
                </Form>
              )
            }}
          </Formik>
        </Box>
      </Slide>
    </Modal>
  )
}

export default memo(CreateNewOldVariableModal)
