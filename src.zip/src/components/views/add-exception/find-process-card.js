import { memo, useState, useRef } from 'react'
import queryString from 'query-string';
import { useLocation } from 'react-router-dom';
import classNames from 'classnames';
import axios from 'axios';
import { Typography, Alert, Collapse, Stack } from '@mui/material';
import HtmlParser from 'html-react-parser';
// *** shared ***
import SharedTextfieldAndSubmit from 'shared/forms/textfield-and-submit'
// *** components ***
import Card from "components/Card"
import CardIcon from 'components/Card/CardIcon';
import CardBody from 'components/Card/CardBody';
import CardFooter from 'components/Card/CardFooter';
// *** Icons ***
import ExceptionIcon from '@mui/icons-material/BugReport';
import FindProcessIcon from '@mui/icons-material/Memory';
import FindProjectIcon from '@mui/icons-material/Build';
// *** styles ***
import { createUseStyles } from 'react-jss';
import { FindProcessCardStyles } from 'assets/styles/views/add-exception.styles';
import { useEffect } from 'react';
const useStyles = createUseStyles(FindProcessCardStyles)



function FindProcessCard({ jobID, fpsIsLoading, setFpsIsLoading, openAnalyticsPage, onError }) {
    const classes = useStyles();
    const location = useLocation();
    const parsed = queryString.parse(location.search);
    const findProcessRef = useRef(null)
    const findProjectRef = useRef(null)
    const [findProcessIsSubmitting, setFindProcessSubmitting] = useState(false)
    const [findProjectIsSubmitting, setFindProjectSubmitting] = useState(false)


    const [alert, setAlert] = useState({
        open: false,
        severity: "error",
        message: ""
    })


    // useEffect(() => {
    //     findProcessRef.current.setSubmitting(fpsIsLoading)
    //     findProjectRef.current.setSubmitting(fpsIsLoading)
    // }, [fpsIsLoading])

    useEffect(() => {
        if (parsed?.jobID && parsed?.projectNumber && location.hash === "#deployments") {
            findProjectRef.current.setFieldValue("projectNum", parsed?.projectNumber)
            onSubmit({
                processID: null,
                projectNum: parsed?.projectNumber,
                externalAction: true
            })
        }
        else if (parsed?.jobID && parsed?.processInstanceId && location.hash === "#deployments") {
            findProcessRef.current.setFieldValue("processID", parsed?.processInstanceId)
            onSubmit({
                processID: parsed?.processInstanceId,
                projectNum: null,
                externalAction: true
            })
        }
    }, [])

    const onSubmit = ({ processID, projectNum, externalAction = false }) => {
        setFpsIsLoading(true)
        if (processID){
            setFindProcessSubmitting(true)
            setFindProjectSubmitting(false)
        }            
        else {
            setFindProcessSubmitting(false)
            setFindProjectSubmitting(true)
        }

        if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
            //?=================[ DEV ]========================
            setTimeout(() => {
                if (!externalAction)
                    findProcessRef.current.resetForm()
                // **************** ANALYSIS PAGE ****************
                if (processID) {
                    if (!externalAction){
                        setFindProcessSubmitting(false)                        
                        setFpsIsLoading(false)
                    }                        
                    openAnalyticsPage([], processID, "")                    
                }
                else {
                    if (!externalAction){
                        setFindProjectSubmitting(false)
                        setFpsIsLoading(false)
                    }
                        
                    openAnalyticsPage([], "", projectNum)                    
                }
                // **************** ALERT ERROR ****************
                // setAlert({
                //     open: true,
                //     severity: "error",
                //     message: HtmlParser(`
                //         Could not found the 
                //         <strong>${processID ? "Process ID: " : "Project Number: "}</strong> 
                //         <mark 
                //             title="${processID ? processID : projectNum}" 
                //             class="${classes.userEntryErrorNumber}">
                //             ${processID ? processID : projectNum}
                //         </mark>
                //     `)
                // })
            }, 2000)
        }
        else {
            //?=================[ PROD ]========================
            const headers = { "Content-type": "application/json" }
            const body = {
                processInstanceId: processID ? processID : "",
                projectNum: projectNum ? projectNum : "",
                jobId: jobID
            }

            axios
                .post(`/api/analysisExceptionProcess`, body, { headers })
                .then(response => {
                    // ****************** openAnalyticsPage ******************
                    if (processID) {
                        if (!externalAction){
                            setFindProcessSubmitting(false)                        
                            setFpsIsLoading(false)
                        }                            
                        openAnalyticsPage(response.data, processID, "")
                    }
                    else {
                        if (!externalAction){
                            setFindProjectSubmitting(false)
                            setFpsIsLoading(false)
                        }                            
                        openAnalyticsPage(response.data, "", projectNum)
                    }
                    // *******************************************************
                    findProcessRef.current.resetForm()
                    setAlert({ open: false, severity: "error", message: "" })
                })
                .catch(error => {
                    onError(error)
                    if (!externalAction) {
                        if (processID){
                            setFindProcessSubmitting(false)
                            setFpsIsLoading(false)
                        }                            
                        else {
                            setFindProjectSubmitting(false)
                            setFpsIsLoading(false)
                        }
                    }

                    setAlert({
                        open: true,
                        severity: "error",
                        message: HtmlParser(`
                            Could not found the 
                            <strong>${processID ? "Process ID: " : "Project Number: "}</strong> 
                            <mark 
                                title="${processID ? processID : projectNum}" 
                                class="${classes.userEntryErrorNumber}">
                                ${processID ? processID : projectNum}
                            </mark>
                        `)
                    })
                })
        }
    }

    return (
        <div className={classes.findProcessRoot}>
            <Card className="find-process-card">
                <div className="find-process-card-icon-wrapper">
                    <CardIcon color="primary">
                        <ExceptionIcon />
                    </CardIcon>
                </div>

                <CardBody>
                    <Typography variant="h3" component="h3" className="find-process-card-title">
                        Add Exception
                    </Typography>

                    <Collapse in={alert.open}>
                        <Alert variant="outlined" severity={alert.severity} className="alert-section">
                            {alert.message}
                        </Alert>
                    </Collapse>

                    <div className={classNames("form-wrapper", { "with-alert-open-above": alert.open })}>
                        <Stack direction="row" justifyContent="center" spacing={4}>
                            <div id="find-process">
                                <SharedTextfieldAndSubmit
                                    ref={findProcessRef}
                                    name="processID"
                                    labelText="Process ID"
                                    buttonTxt="Find Process"
                                    startIcon={<FindProcessIcon />}
                                    required
                                    disabled={(findProcessIsSubmitting || findProjectIsSubmitting) && fpsIsLoading}
                                    isSubmitting={findProcessIsSubmitting && fpsIsLoading}
                                    onSubmit={onSubmit}
                                />
                            </div>
                            <div id="find-project">
                                <SharedTextfieldAndSubmit
                                    ref={findProjectRef}
                                    name="projectNum"
                                    labelText="Project Number"
                                    buttonTxt="Find Project"
                                    startIcon={<FindProjectIcon />}
                                    required
                                    disabled={(findProcessIsSubmitting || findProjectIsSubmitting) && fpsIsLoading}
                                    isSubmitting={findProjectIsSubmitting && fpsIsLoading}
                                    onSubmit={onSubmit}
                                />
                            </div>
                        </Stack>
                    </div>
                </CardBody>
                <CardFooter />
            </Card>
        </div>
    )
}

export default memo(FindProcessCard)
