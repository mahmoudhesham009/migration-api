import { memo, useState, useContext } from 'react'
import { useNavigate } from 'react-router-dom';
import { Box, Avatar, Menu, MenuItem, ListItemIcon, IconButton, Tooltip, Badge } from '@mui/material';
import { styled } from '@mui/material/styles';
// *** context ***
import { ConnectionContext } from 'App'
// *** hooks ***
import useAuthentication from 'hooks/redux-hook/useAuthentication';
// *** Icons ***
import LogoutIcon from '@mui/icons-material/Logout';
// *** styles ***
import { AccountWithBadgeStyles, AccountMenuPaperStyles } from 'assets/styles/layout/mainLayout.styles'
const StyledBadge = styled(Badge, {
    shouldForwardProp: (prop) => prop !== "isOnline"
})(AccountWithBadgeStyles)


function AccountDropdown() {

    const { LogoutFromSystem } = useAuthentication()
    const navigate = useNavigate()
    const [anchorEl, setAnchorEl] = useState(null);
    const { isOnline } = useContext(ConnectionContext)
    const open = Boolean(anchorEl);

    const handleClickOpenMenu = (event) => setAnchorEl(event.currentTarget)
    const handleClickCloseMenu = () => setAnchorEl(null);
    const Logout = () => {
        navigate("/")
        LogoutFromSystem()
    }

    return (
        <Box>
            <Tooltip title="Account settings">
                <IconButton
                    onClick={handleClickOpenMenu}
                    size="small"
                    sx={{ ml: 2 }}
                >
                    <StyledBadge
                        overlap="circular"
                        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                        variant="dot"
                        isOnline={isOnline}
                    >
                        <Avatar src="/us-flag.png" />
                    </StyledBadge>
                </IconButton>
            </Tooltip>
            <Menu
                anchorEl={anchorEl}
                id="account-menu"
                open={open}
                onClose={handleClickCloseMenu}
                onClick={handleClickCloseMenu}
                PaperProps={{
                    elevation: 0,
                    sx: { ...AccountMenuPaperStyles }
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            >
                <MenuItem onClick={Logout}>
                    <ListItemIcon>
                        <LogoutIcon fontSize="small" />
                    </ListItemIcon>
                    Logout
                </MenuItem>
            </Menu>
        </Box>
    )
}

export default memo(AccountDropdown)